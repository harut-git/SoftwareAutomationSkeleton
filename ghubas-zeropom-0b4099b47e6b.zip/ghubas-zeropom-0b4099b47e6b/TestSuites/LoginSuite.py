import allure

from Base.BaseSuite import BaseSuite
from Modules.login import login
from Pages.AddinsPage import AddinsPage
from Pages.OutlookWindowPage import OutlookWindowPage
from Pages.RibbonPage import RibbonPage
from Utils.RegistryEditor import clean_restrictions


class LoginSuite(BaseSuite):
    def setUp(self):
        """ Written below runs first while running any test from this TestCase. """
        print(clean_restrictions())
        if self.runner.start_outlook() and self.runner.start_winium():
            if not OutlookWindowPage.inst().outlook_is_opened():
                print("Outlook not started")
                self.tearDown()
            print("Outlook is opened")
        else:
            self.tearDown()

    def test_check_that_after_logout_and_outlook_restart_Plugin_state_is_logged_out(self):
        """ ZO-846 """
        with allure.step("Performing Login... "):
            login()
        with allure.step("Opening Settings... "):
            RibbonPage().inst().open_settings()
        with allure.step("Logging out from Settings Dialog... "):
            RibbonPage().inst().ribbon_settings_dialog_logout()
        with allure.step("Restarting Outlook... "):
            RibbonPage().inst().restart_outlook()
        with allure.step("Opening Outlook..."):
            self.runner.start_outlook()
            if not OutlookWindowPage.inst().outlook_is_opened():
                print("Outlook not started")
        with allure.step("Checking Addin Logo is visible..."):
            assert AddinsPage.inst().check_addin_visible() is True
        with allure.step("Logging in on finish..."):
            login()

    def test_check_that_sync_process_starts_right_after_login_and_only_settings_is_active(self):
        """ ZO-844, ZO-845 """
        with allure.step("Performing Login... "):
            login()
        with allure.step("Checking that only Settings button is active... "):
            assert len(RibbonPage.inst().get_ribbon_active_buttons()) == 1
            assert RibbonPage.inst().get_ribbon_active_buttons()[0].get_attribute("Name") == "Settings"
        with allure.step("Checking that status is Sync with Net Documents... "):
            assert RibbonPage.inst().get_status() == "Syncing with NetDocuments"
