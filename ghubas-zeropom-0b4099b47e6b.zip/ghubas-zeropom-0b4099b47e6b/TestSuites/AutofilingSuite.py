import time

import allure

from Base.BaseSuite import BaseSuite
from Pages.FoldersPage import FoldersPage
from Pages.InboxPage import InboxPage
from Pages.InspectorPage import InspectorPage
from Pages.RibbonPage import RibbonPage
from Pages.RightClickMenuPage import RightClickMenuPage
from Pages.RightClickPropsMenuPage import RightClickPropsMenuPage
from Pages.TaskPanePage import TaskPanePage


class AutofilingSuite(BaseSuite):

    def test_check_state_of_notfiled_mail_sent_to_external_recipient_when_autofile_off_quickfile_without_autofile_convers_and_refresh(
            self):
        """ ZO-1042 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Ready to file state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"

    def test_check_state_of_notfiled_mail_sent_to_external_recipient_when_autofile_off_quickfile_with_autofile_convers_and_refresh(
            self):
        """ ZO-1043 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Checking that Autofile checkbox state is ON "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is True
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
            time.sleep(2)
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
            time.sleep(2)
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Waiting until new message will not have Ready to file state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"

    def test_check_state_of_notfiled_mail_sent_to_external_recipient_when_autofile_on_quickfile_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1044 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        # with allure.step("Checking that Autofile checkbox state is OFF "):
        #     assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
            time.sleep(5)
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed", wait=30):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"

    def test_check_state_of_notfiled_mail_sent_to_external_recipient_when_autofile_on_quickfile_with_autofile_convers_with_regular_sync(
            self):
        """ ZO-1045 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Checking that Autofile checkbox state is ON "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is True
        # with allure.step("Checking that Autofile checkbox state is OFF "):
        #     assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
            time.sleep(5)
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed", wait=30):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"

    def test_check_state_of_notfiled_mail_with_two_pred_sent_to_external_recipient_when_autofile_off_quickfile_without_autofile_convers_and_refresh(
            self):
        """ ZO-1046 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        # with allure.step("Waiting until new message will not have Not Filed state..."):
        #     if InboxPage().inst().wait_for_element_status(message_element, ""):
        #         print "Filing status is grabbed..."
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_notfiled_mail_with_two_pred_sent_to_external_recipient_when_autofile_off_file_with_diff_attrs_with_autofile_convers_with_regular_sync(
            self):
        """ ZO-1047 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step(
                "Scroll Down to locate the AutoFile this conversation checkbox anf File button into TaskPane "):
            assert TaskPanePage().inst().scroll_to_locate_file_button() is True
        with allure.step("Activate an Autofile checkbox with different attributes "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox_with_diff_attrs() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_notfiled_mail_with_two_pred_sent_to_external_recipient_when_autofile_on_file_with_diff_attrs_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1048 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step(
                "Scroll Down to locate the AutoFile this conversation checkbox anf File button into TaskPane "):
            assert TaskPanePage().inst().scroll_to_locate_file_button() is True
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        # with allure.step("Clicking on Refresh button from Ribbon "):
        #     assert RibbonPage().inst().click_on_refresh_button() is True
        # with allure.step("Waiting for up to date "):
        #     RibbonPage.inst().waiting_for_up_to_date_status()
        #     time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_notfiled_mail_with_two_pred_sent_to_external_recipient_when_autofile_on_file_with_diff_attrs_with_autofile_convers_with_regular_sync(
            self):
        """ ZO-1049 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening new mail Composer..."):
            RibbonPage.inst().open_mail_composer()
            time.sleep(2)
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Entering ito Sent Items TOE..."):
            assert FoldersPage().inst().sent_items_pane() is True
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            assert RibbonPage.inst().open_task_pane() is True
            time.sleep(2)
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step(
                "Scroll Down to locate the AutoFile this conversation checkbox anf File button into TaskPane "):
            assert TaskPanePage().inst().scroll_to_locate_file_button() is True
        with allure.step("Activate an Autofile checkbox with different attributes "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox_with_diff_attrs() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Opening new mail Composer..."):
            assert RibbonPage.inst().open_mail_composer() is True
        with allure.step("Checking if Composer is Opened..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        with allure.step("Composing new email with given parameters..."):
            assert InspectorPage().inst().inspector_compose_new_email_with_minimum_set_of_data() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Checking if Composer is Closed..."):
            assert InspectorPage().inst().inspector_get_title_of_new_email() is True
        # with allure.step("Clicking on Refresh button from Ribbon "):
        #     assert RibbonPage().inst().click_on_refresh_button() is True
        # with allure.step("Waiting for up to date "):
        #     RibbonPage.inst().waiting_for_up_to_date_status()
        #     time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_notfiled_mail_with_pred_received_from_external_sender_when_autofile_off_quickfile_without_autofile_convers_and_refresh(
            self):
        """ ZO-1050 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Ready to file state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"

    def test_check_state_of_notfiled_mail_with_pred_received_from_external_sender_when_autofile_off_quickfile_with_autofile_convers_and_refresh(
            self):
        """ ZO-1051 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Ready to file state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"

    def test_check_state_of_notfiled_mail_with_pred_received_from_external_sender_when_autofile_on_quickfile_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1052 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"

    def test_check_state_of_notfiled_mail_with_pred_received_from_external_sender_when_autofile_on_quickfile_with_autofile_convers_with_regular_sync(
            self):
        """ ZO-1053 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"

    def test_check_state_of_notfiled_mail_with_two_pred_received_from_external_sender_when_autofile_off_quickfile_without_autofile_convers_and_refresh(
            self):
        """ ZO-1054 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_notfiled_mail_with_two_pred_received_from_external_sender_when_autofile_off_quickfile_with_autofile_convers_and_refresh(
            self):
        """ ZO-1055 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_notfiled_mail_with_two_pred_received_from_external_sender_when_autofile_on_quickfile_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1056 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
            time.sleep(2)
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_notfiled_mail_with_two_pred_received_from_external_sender_when_autofile_on_quickfile_with_autofile_convers_with_regular_sync(
            self):
        """ ZO-1057 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="991") is True
            time.sleep(2)
        with allure.step(
                "Choose Different Matter Attribute for filing operation to get second and different prediction "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Doctype",
                                                                                                        value="004") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
            time.sleep(2)
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_not_filed_mail_from_internal_sender_when_autofile_off_file_without_autofile_convers_and_refresh(
            self):
        """ ZO-1058 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Choose Different Matter Attribute for filing operation "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="551") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_not_filed_mail_from_internal_sender_when_autofile_on_file_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1059 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Choose Different Matter Attribute for filing operation "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="551") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
            time.sleep(2)
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_not_filed_mail_from_internal_sender_when_autofile_off_file_with_autofile_convers_and_refresh(
            self):
        """ ZO-1060 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Choose Different Matter Attribute for filing operation "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="551") is True
            time.sleep(2)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox_with_diff_attrs() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_not_filed_mail_from_internal_sender_when_autofile_on_file_with_autofile_convers_with_regular_sync(
            self):
        """ ZO-1061 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Choose Different Matter Attribute for filing operation "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="551") is True
            time.sleep(2)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox_with_diff_attrs() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Getting an smtp internal message..."):
            message_element = InboxPage.inst().have_internal_message()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
            time.sleep(2)
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on the last sent message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Check that the state of new mail is Not Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_ready_to_file_mail_from_notfiled_mail_thread_with_pred_received_from_external_sender_when_autofile_off_quickfile_without_autofile_convers_and_refresh(
            self):
        """ ZO-1062 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"
        with allure.step("Clicking on new message..."):
            second_element = InboxPage().inst().get_second_message()
            second_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(second_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(second_element) == "Ready to file"

    def test_check_state_of_ready_to_file_mail_from_notfiled_mail_thread_with_pred_received_from_external_sender_when_autofile_on_quickfile_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1063 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"
        with allure.step("Clicking on new message..."):
            second_element = InboxPage().inst().get_second_message()
            second_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(second_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(second_element) == "Ready to file"

    def test_check_state_of_ready_to_file_mail_from_various_state_mail_thread_with_pred_received_from_external_sender_when_autofile_off_quickfile_without_autofile_convers_and_refresh(
            self):
        """ ZO-1064, ZO-1066 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(3)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has no filing status..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+2]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"

    def test_check_state_of_ready_to_file_mail_from_various_state_mail_thread_with_pred_received_from_external_sender_when_autofile_on_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1065 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(3)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has Filed status..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_ready_to_file_mail_from_various_state_mail_thread_with_pred_received_from_external_sender_when_autofile_off_quickfile_with_autofile_convers_and_refresh(
            self):
        """ ZO-1067 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(3)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has Filed status..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has no filing status..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"

    def test_check_state_of_ready_to_file_mail_from_various_state_mail_thread_with_pred_received_from_external_sender_when_autofile_on_quickfile_without_autofile_convers_with_regular_sync(
            self):
        """ ZO-1068 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(3)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has Filed status..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has Filed status..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"

    def test_check_state_of_ready_to_file_mail_from_various_state_mail_thread_with_pred_received_from_external_sender_when_autofile_on_quickfile_with_autofile_convers_with_regular_sync(
            self):
        """ ZO-1069 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(3)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Activate an Autofile checkbox "):
            assert TaskPanePage().inst().click_on_auto_file_checkbox() is True
        with allure.step("Handling Autofile option dialog window "):
            assert TaskPanePage().inst().auto_file_checkbox_dialog_handling() is True
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has Filed status..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has Filed status..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"

    def test_check_state_of_mails_from_thread_with_multiple_ready_to_file_mails_with_pred_received_from_external_sender_when_autofile_off_and_refresh(
            self):
        """ ZO-1070 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(3)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread_to_the_same_sender() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Closing Settings dialog window "):
            assert RibbonPage().inst().close_settings() is True
        with allure.step("Clicking on Refresh button from Ribbon "):
            assert RibbonPage().inst().click_on_refresh_button() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"

    def test_check_state_of_mails_from_thread_with_multiple_ready_to_file_mails_with_pred_received_from_external_sender_when_autofile_on_with_regular_sync(
            self):
        """ ZO-1071 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(3)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread_to_the_same_sender() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Opening Settings dialog window "):
            assert RibbonPage().inst().open_settings() is True
        with allure.step("Checking the state of AutoFile OFF radio button "):
            assert RibbonPage().inst().ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected() is True
        with allure.step("Activating AutoFile ON mode from Settings "):
            assert RibbonPage().inst().ribbon_settings_dialog_click_on_autofileon_radiobutton() is True
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is not a Filed..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"
