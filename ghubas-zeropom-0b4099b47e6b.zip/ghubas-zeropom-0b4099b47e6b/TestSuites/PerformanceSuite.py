import datetime
import time

import allure

from Base.BaseSuite import BaseSuite
from Pages.InboxPage import InboxPage
from Utils.PerformanceMonitor import get_metrics


class PerformanceSuite(BaseSuite):
    def test_check_performance_while_navigating_in_Inbox(self):
        # login()
        # with allure.step("Waiting for up to date... "):
        #     RibbonPage.inst().waiting_for_up_to_date_status()
        start_ts = datetime.datetime.utcnow().isoformat()[:-8] + "5"
        time.sleep(15)
        # with allure.step("Opening Task Pane... "):
        #     RibbonPage().inst().open_task_pane()
        with allure.step("Getting metrics"):
            print(get_metrics(start_ts))
        with allure.step("Navigating through emails"):
            messages_clicked = InboxPage.inst().navigate_emails()
        with allure.step("Scrolling Inbox... "):
            InboxPage.inst().scroll_down(messages_clicked)
        with allure.step("Navigating through emails"):
            messages_clicked = InboxPage.inst().navigate_emails()
        with allure.step("Scrolling Inbox... "):
            InboxPage.inst().scroll_down(messages_clicked)
            end_ts = datetime.datetime.utcnow().isoformat()[:-8] + "5"
            time.sleep(10)
            print(get_metrics(end_ts))

