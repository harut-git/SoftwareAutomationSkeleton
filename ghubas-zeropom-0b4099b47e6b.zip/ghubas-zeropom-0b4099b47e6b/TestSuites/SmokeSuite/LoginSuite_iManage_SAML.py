import allure

from Base.BasePage import BasePage
from Base.BaseSuite import BaseSuite
from Pages.AddinsPage import AddinsPage
from Pages.RibbonPage import RibbonPage


class LoginSuite(BaseSuite):

    def test_check_that_sync_process_starts_right_after_login(self):
        """  """
        with allure.step("Performing Login... "):
            AddinsPage().inst().addin_login()
            AddinsPage().inst().imanage_frame_login_saml()

        with allure.step("Checking that Refresh button is active... "):
            assert BasePage().wait_and_get_name(RibbonPage.inst().get_ribbon_active_buttons()[3].get_attribute("Name"))
            assert RibbonPage.inst().get_ribbon_active_buttons()[2].get_attribute("Name") == "Refresh"