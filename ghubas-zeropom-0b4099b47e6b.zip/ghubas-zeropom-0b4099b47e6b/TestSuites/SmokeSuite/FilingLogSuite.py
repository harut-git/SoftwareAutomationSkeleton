import allure
import time

from Base.BaseSuite import BaseClassSuite
from Modules.login import login
from Pages.FilingLogPage import FilingLogPage
from Pages.InboxPage import InboxPage
from Pages.RibbonPage import RibbonPage
from Pages.TaskPanePage import TaskPanePage


class FilingLogSuite(BaseClassSuite):

    def test_filed_message_properties(self):
        login()
        with allure.step("Selecting message from TOE and filing"):
            msg_element = InboxPage.inst().get_first_message()
            TaskPanePage.inst().get_custom_attribute_values()
            msg_element.click()
            TaskPanePage.inst().click_file_button()
        with allure.step("Waiting that message to be filed"):
            assert InboxPage.inst().wait_for_element_status(msg_element, "Filed") is True
            k = InboxPage.inst().get_message_params(msg_element)
            print(k.msg_destination)
            k.msg_filed_date = time.strftime("%#m/%#d/%Y")
        with allure.step("Opening filing log... "):
            RibbonPage().inst().open_filing_log()
        with allure.step("Filing Log is opened"):
            assert FilingLogPage().inst().filinglog_is_opened() is True
        with allure.step("Checking that filed message exists in filing log"):
            msg_element_in_filing_log = FilingLogPage.inst().get_first_filed_message()
            msg_obj = FilingLogPage.inst().get_filed_message_params(msg_element_in_filing_log)
            assert msg_obj.msg_destination == k.msg_destination
            assert msg_obj.msg_filed_date == k.msg_filed_date
            assert msg_obj.msg_subject == k.msg_subject
            assert msg_obj.msg_from == k.msg_from
            print(msg_obj.msg_auto_filed)
        with allure.step("Unfiling email from filing log"):
            FilingLogPage.inst().unfile_message()
            assert FilingLogPage.inst().is_empty() is True
            FilingLogPage.inst().close_filinglog_dialog()
            msg_element = InboxPage.inst().get_first_message()
            msg_after_unfile = InboxPage.inst().get_message_params(msg_element)
            assert msg_after_unfile.msg_status == "Unfiled"

    def test_ready_to_file_message_properties(self):
        """Checking Ready to File status appear/disappearing"""
        with allure.step("Selecting message from TOE and checking that it is Ready to File"):
            msg_element = InboxPage.inst().get_inbox_message_by_count(7)
            msg_element.click()
            assert InboxPage.inst().wait_for_element_status(msg_element, "Ready to file") is True

        with allure.step("Filing one message which has no predictions"):
            msg_no_status_element = InboxPage.inst().get_inbox_message_by_count(2)
            msg_no_status_element.click()
            TaskPanePage.inst().set_attribute_value('Client')
            TaskPanePage.inst().set_attribute_value('Matter')
            TaskPanePage.inst().set_attribute_value('Author')
            TaskPanePage.inst().set_attribute_value("Doctype")
            TaskPanePage.inst().click_file_button()
            assert InboxPage.inst().wait_for_element_status(msg_no_status_element, "Filed") is True


        with allure.step("Refreshing and checking that the same recipient having email got Ready to File status"):
            RibbonPage.inst().click_on_refresh_button()
            msg_rtf_element = InboxPage.inst().get_inbox_message_by_count(6)
            msg_rtf_element.click()
            assert InboxPage.inst().wait_for_element_status(msg_rtf_element, "Ready to file") is True

        with allure.step("Unfiling message and checking that after Refresh Ready to File disappears"):
            msg_fld_element = InboxPage.inst().get_inbox_message_by_count(2)
            msg_fld_element.click()
            TaskPanePage.inst().click_unfile_button()
            RibbonPage.inst().click_on_refresh_button()
            msg_no_sts_element = InboxPage.inst().get_inbox_message_by_count(6)
            msg_no_sts_element.click()
            assert InboxPage.inst().wait_for_element_status(msg_no_sts_element, "Ready to file") is False
