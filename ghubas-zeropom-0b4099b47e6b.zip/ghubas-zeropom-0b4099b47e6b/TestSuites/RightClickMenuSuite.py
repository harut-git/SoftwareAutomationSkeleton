import time

import allure

from Base.BaseSuite import BaseSuite
from Pages.InboxPage import InboxPage
from Pages.RibbonPage import RibbonPage
from Pages.RightClickMenuPage import RightClickMenuPage
from Pages.RightClickPropsMenuPage import RightClickPropsMenuPage
from Pages.TaskPanePage import TaskPanePage
from Utils.CabinetProfiles import rmkb_replicated


class RightClickMenuSuite(BaseSuite):

    def test_check_that_taskpane_is_closing_on_popup_opening(self):
        """ ZO-745 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_never_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            assert RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened() is True
            # time.sleep(2)
        with allure.step("Checking if Task Pane is Opened - Should be Closed!..."):
            assert TaskPanePage().inst().is_opened() is False
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()
            # time.sleep(2)
        with allure.step("Checking if Task Pane is Opened - Should be Opened!..."):
            assert TaskPanePage().inst().is_opened() is True

    def test_check_if_only_filing_attributes_are_available_on_the_screen(self):
        """ ZO-746, ZO-747, ZO-753 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_never_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            assert RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened() is True
        with allure.step("Checking if the value of Client attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Client")[
                       0].text == ""
        with allure.step("Checking if the value of Matter attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Matter")[
                       1].text == ""
        with allure.step("Checking if the value of Author attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Author")[
                       2].text == "002 - poxosikzeroapp@yahoo.com"
        with allure.step("Checking if the value of Doctype attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Doctype")[
                       3].text == "006 - Other (3rd party)"
        with allure.step("Checking if Filing Attributes correspond to the Cabinet's attributes list..."):
            attr_list = RightClickMenuPage().inst().get_attributes_list_from_rightclick_filing_dialog_window()
            for i in attr_list:
                print(i.get_attribute("Name"))
                assert i.get_attribute("Name") in rmkb_replicated
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()

    # def test_check_if_quick_file_and_details_buttons_are_presented_on_the_screen(self):
    #     """ ZO-748 """
    #     with allure.step("Waiting for up to date "):
    #         RibbonPage.inst().waiting_for_up_to_date_status()
    #     with allure.step("Getting an smtp not filed message with prediction..."):
    #         message_element = InboxPage.inst().have_not_filed_message_with_prediction()
    #         assert message_element is not False
    #         time.sleep(5)
    #     with allure.step("Getting an smtp not filed message with prediction..."):
    #         message_element = InboxPage.inst().have_not_filed_message_with_prediction()
    #         assert message_element is not False
    #         time.sleep(2)
    #     with allure.step("Right Click on new message..."):
    #         InboxPage().inst().open_right_click_props_menu(message_element)
    #     with allure.step("Click on Zero File pop-up menu item..."):
    #         RightClickPropsMenuPage().inst().click_zero_file()
    #     with allure.step("Opening Pop-up Filing dialog..."):
    #         RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
    #     with allure.step("Click on Details button..."):
    #         RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_details_button()
    #     with allure.step("Click on Less button..."):
    #         RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_less_button()
    #     with allure.step("Click on QuickFile button..."):
    #         RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_quickfile_button()

    def test_check_if_quick_file_and_details_buttons_are_presented_and_functional_on_the_screen(self):
        """ ZO-748 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with ready to file status..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            assert message_element is not False
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Click on Details button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_details_button()
        with allure.step("Click on Less button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_less_button()
        with allure.step("Click on QuickFile button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_quickfile_button()

    def test_check_if_all_predicted_attributes_are_prefilled_on_details_button_click(self):
        """ ZO-749 - ZO-751 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with ready to file status..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            assert message_element is not False
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Click on Details button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_details_button()
        # with allure.step("Checking if the value of Client attribute is set correctly..."):
        #     assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Client")[
        #                0].text == ""
        # with allure.step("Checking if the value of Matter attribute is set correctly..."):
        #     assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Matter")[
        #                1].text == ""
        with allure.step("Checking if the value of Author attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Author")[
                       2].text != ""
        with allure.step("Checking if the value of Doctype attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Doctype")[
                       3].text != ""
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()

    def test_check_if_mail_is_filed_with_predicted_attributes(self):
        """ ZO-752, ZO-753 - the behavior of dialog window is different, opened with predictions and QuickFile ready """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with ready to file status..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            assert message_element is not False
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Click on QuickFile button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_quickfile_button()
        with allure.step("Opening Task Pane..."):
            RibbonPage().inst().open_task_pane()
            assert TaskPanePage().inst().is_opened() is True
        with allure.step("Getting the destination from Task Pane..."):
            dest_from_task_pane = TaskPanePage().inst().get_filed_message_destination()
        with allure.step("Getting the destination from TOE..."):
            message_element = InboxPage().inst().get_first_message()
            dest_from_toe = InboxPage().inst().get_message_data(message_element)[4]
        with allure.step("Comparing the destinations from Task Pane and TOE..."):
            assert dest_from_task_pane == dest_from_toe

    def test_check_that_taskpane_is_closing_on_popup_opening_and_filing_with_different_attributes(self):
        """ ZO-754 - HAS BLOCKER ISSUE WITH INFINITE ATTRIBUTE VALUES LOADING """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Checking if Task Pane is Opened - Should be Closed!..."):
            assert TaskPanePage().inst().is_opened() is False
        with allure.step("Click to Choose Different Attributes button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_to_choose_diff_attr_button()
        with allure.step("Getting Attributes values from Pop-up Filing dialog..."):
            TaskPanePage().inst().get_attributes_list()
        with allure.step("Setting Attribute value for Client into Pop-up Filing dialog..."):
            RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Client",
                                                                                                 value="001 - Client 1")
        with allure.step("Setting Attribute value for Matter into Pop-up Filing dialog..."):
            RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Client", value="111")
        with allure.step("Click to Choose Different Attributes button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_file_button()
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()
        with allure.step("Checking if Task Pane is Opened - Should be Opened!..."):
            assert TaskPanePage().inst().is_opened() is True

    def test_check_that_taskpane_is_closing_on_popup_opening_for_filed_mail(self):
        """ ZO-755 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Checking if Task Pane is Opened - Should be Closed!..."):
            assert TaskPanePage().inst().is_opened() is False
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_last_filing_dialog_window()
        with allure.step("Checking if Task Pane is Opened - Should be Opened!..."):
            assert TaskPanePage().inst().is_opened() is True

    def test_check_if_destination_and_attributes_list_are_displayed_on_popup_opening_for_filed_mail(self):
        """ ZO-756 - ZO-758, ZO-771, ZO-772 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Dumping the filed content data from Pop-up Last Filing dialog..."):
            assert RightClickMenuPage().inst().rightclick_filing_dialog_window_get_filed_content_data() is True
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert RightClickMenuPage().inst().rightclick_last_filing_dialog_window_get_autofile_checkbox_state() is False
        with allure.step("Clicking on Autofile checkbox "):
            RightClickMenuPage().inst().rightclick_last_filing_dialog_window_click_on_autofile_checkbox()
        with allure.step("Checks if AutoFile option dialog window is opened "):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_autofile_option_window_is_opened()
        with allure.step("From AutoFile option dialog window click on OK button "):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_autofile_option_window_click_on_ok()
        with allure.step("Checking that Autofile checkbox state is ON "):
            assert RightClickMenuPage().inst().rightclick_last_filing_dialog_window_get_autofile_checkbox_state() is True
        with allure.step("Click on Re-File button "):
            RightClickMenuPage().inst().rightclick_last_filing_dialog_window_click_on_refile_button()
        with allure.step("Checks if Move to new destination dialog window is opened "):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_move_to_new_destination_window_is_opened()
        with allure.step("From Move to new destination dialog window click on ReFile button "):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_move_to_new_destination_window_click_on_refile()
        with allure.step("Setting Attribute value for Client into Pop-up Filing dialog..."):
            RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Client",
                                                                                                 value="001 - Client 1")
        time.sleep(2)
        with allure.step("Setting Attribute value for Matter into Pop-up Filing dialog..."):
            RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Client", value="111")
        time.sleep(2)
        with allure.step("Click to Choose Different Attributes button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_file_button()

    def test_check_if_mail_is_being_set_to_in_process_state_during_filing(self):
        """ ZO-759 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message and getting the status..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
            # time.sleep(5)
        with allure.step("Waiting until new message will not have Ready to File state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
                with allure.step("Right Click on new message..."):
                    InboxPage().inst().open_right_click_props_menu(message_element)
                with allure.step("Click on Zero File pop-up menu item..."):
                    if RightClickPropsMenuPage().inst().click_zero_file():
                        with allure.step("Check if new message will have In-Process state during filing action..."):
                            assert InboxPage().inst().get_message_status(message_element) == "In-Process"
                with allure.step("Check if Pop-up Filing dialog is opened..."):
                    assert RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened() is False

    def test_check_that_taskpane_is_closing_on_popup_opening_for_unfiled_mail(self):
        """ ZO-760 - description should be changed, Task Pane should be opened during unfiling action, not closed! """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero UnFile pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_unfile()
        with allure.step("Opening UnFile emails dialog..."):
            RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
        with allure.step("Checking if Task Pane is Opened!..."):
            assert TaskPanePage().inst().is_opened() is True

    def test_check_if_only_filing_attributes_are_available_on_the_screen_for_unfiled_mail(self):
        """ ZO-761, ZO-762 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero UnFile pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_unfile()
        with allure.step("Opening UnFile emails dialog..."):
            RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Click to Choose Different Attributes button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_to_choose_diff_attr_button()
        with allure.step("Checking if the value of Client attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Client")[
                       0].text == ""
        with allure.step("Checking if the value of Matter attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Matter")[
                       1].text == ""
        with allure.step("Checking if the value of Author attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Author")[
                       2].text != ""
        with allure.step("Checking if the value of Doctype attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Doctype")[
                       3].text != ""
        with allure.step("Checking if Filing Attributes correspond to the Cabinet's attributes list..."):
            attr_list = RightClickMenuPage().inst().get_attributes_list_from_rightclick_filing_dialog_window()
            for i in attr_list:
                print(i.get_attribute("Name"))
                assert i.get_attribute("Name") in rmkb_replicated
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()

    def test_check_if_quick_file_and_details_buttons_are_presented_and_functional_on_the_screen_for_unfiled_mail(self):
        """ ZO-763 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero UnFile pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_unfile()
        with allure.step("Opening UnFile emails dialog..."):
            RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Click on Details button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_details_button()
        with allure.step("Click on Less button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_less_button()
        with allure.step("Click on QuickFile button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_quickfile_button()

    def test_check_if_all_predicted_attributes_are_prefilled_on_details_button_click_for_unfiled_mail(self):
        """ ZO-764 - ZO-766 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero UnFile pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_unfile()
        with allure.step("Opening UnFile emails dialog..."):
            RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Click on Details button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_details_button()
        with allure.step("Checking if the value of Client attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Client")[
                       0].text != ""
        with allure.step("Checking if the value of Matter attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Matter")[
                       1].text != ""
        with allure.step("Checking if the value of Author attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Author")[
                       2].text != ""
        with allure.step("Checking if the value of Doctype attribute is set correctly..."):
            assert RightClickMenuPage().inst().get_attribute_value_from_rightclick_filing_dialog_window("Doctype")[
                       3].text != ""
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()

    def test_check_if_mail_is_filed_with_predicted_attributes_for_unfiled_mail(self):
        """ ZO-767, ZO-768 - the behavior of dialog window is different, opened with predictions and QuickFile ready """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero UnFile pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_unfile()
        with allure.step("Opening UnFile emails dialog..."):
            RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Click on QuickFile button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_quickfile_button()
        with allure.step("Opening Task Pane..."):
            RibbonPage().inst().open_task_pane()
            assert TaskPanePage().inst().is_opened() is False
        with allure.step("Opening Task Pane..."):
            RibbonPage().inst().open_task_pane()
            assert TaskPanePage().inst().is_opened() is True
        with allure.step("Getting the destination from Task Pane..."):
            dest_from_task_pane = TaskPanePage().inst().get_filed_message_destination()
        with allure.step("Getting the destination from TOE..."):
            message_element = InboxPage().inst().get_first_message()
            dest_from_toe = InboxPage().inst().get_message_data(message_element)[4]
        with allure.step("Comparing the destinations from Task Pane and TOE..."):
            assert dest_from_task_pane == dest_from_toe

    def test_check_that_taskpane_is_closing_on_popup_opening_and_filing_with_different_attributes_for_unfiled_mail(self):
        """ ZO-769 - HAS BLOCKER ISSUE WITH INFINITE ATTRIBUTE VALUES LOADING """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero UnFile pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_unfile()
        with allure.step("Opening UnFile emails dialog..."):
            RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Zero File pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_zero_file()
        with allure.step("Opening Pop-up Filing dialog..."):
            RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened()
        with allure.step("Checking if Task Pane is Opened - Should be Closed!..."):
            assert TaskPanePage().inst().is_opened() is False
        with allure.step("Click to Choose Different Attributes button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_to_choose_diff_attr_button()
        with allure.step("Getting Attributes values from Pop-up Filing dialog..."):
            TaskPanePage().inst().get_attributes_list()
        with allure.step("Setting Attribute value for Client into Pop-up Filing dialog..."):
            RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Client",
                                                                                                 value="001 - Client 1")
            time.sleep(2)
        with allure.step("Setting Attribute value for Matter into Pop-up Filing dialog..."):
            RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter", value="111")
            time.sleep(2)
        with allure.step("Click to Choose Different Attributes button..."):
            RightClickMenuPage().inst().rightclick_filing_dialog_window_click_on_file_button()
        with allure.step("Closing Pop-up Filing dialog..."):
            RightClickMenuPage().inst().close_rightclick_filing_dialog_window()
        with allure.step("Checking if Task Pane is Opened - Should be Opened!..."):
            assert TaskPanePage().inst().is_opened() is True

    def test_check_if_mail_is_being_set_to_in_process_state_during_unfiling(self):
        """ ZO-774 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Clicking on new message and getting the status..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Ready to File state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed"):
                print("Filing status is grabbed...")
                with allure.step("Right Click on new message..."):
                    InboxPage().inst().open_right_click_props_menu(message_element)
                with allure.step("Click on Zero UnFile pop-up menu item..."):
                    RightClickPropsMenuPage().inst().click_zero_unfile()
                with allure.step("Opening UnFile emails dialog..."):
                    RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
                    with allure.step("Check if new message will have In-Process state during unfiling action..."):
                        print(InboxPage().inst().get_message_status(message_element))
                        # assert InboxPage().inst().get_message_status(message_element) == "In-Process"
                with allure.step("Check if Pop-up UnFiling dialog is closed..."):
                    assert RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened() is False
                with allure.step("Checking if Task Pane is Opened - Should be Opened!..."):
                    assert TaskPanePage().inst().is_opened() is True
        with allure.step("Check if new message will have Unfiled state during unfiling action..."):
            assert InboxPage().inst().get_message_status(message_element) == "Unfiled"

    def test_check_that_unfiling_action_is_working_only_for_mails_with_filed_state(self):
        """ ZO-773 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            time.sleep(5)
            assert message_element is not False
        with allure.step("Clicking on new message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
            with allure.step("Check that the state of new mail is not a Filed..."):
                assert InboxPage().inst().get_message_status(message_element) != "Filed"
            with allure.step("Right Click on new message..."):
                InboxPage().inst().open_right_click_props_menu(message_element)
            with allure.step("Check if Zero UnFile pop-up menu item is disabled..."):
                assert RightClickPropsMenuPage().inst().check_zero_unfile_state() is False
                message_element.click()
        with allure.step("Waiting until new message will not have Ready to File state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
                with allure.step("Check that the state of new mail is not a Filed..."):
                    assert InboxPage().inst().get_message_status(message_element) != "Filed"
                with allure.step("Right Click on new message..."):
                    InboxPage().inst().open_right_click_props_menu(message_element)
                with allure.step("Check if Zero UnFile pop-up menu item is disabled..."):
                    assert RightClickPropsMenuPage().inst().check_zero_unfile_state() is False
                    message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Clicking on new message and getting the status..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Waiting until new message will not have Ready to File state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Filed"):
                print("Filing status is grabbed...")
                with allure.step("Right Click on new message..."):
                    InboxPage().inst().open_right_click_props_menu(message_element)
                with allure.step("Click on Zero UnFile pop-up menu item..."):
                    RightClickPropsMenuPage().inst().click_zero_unfile()
                with allure.step("Opening UnFile emails dialog..."):
                    RightClickPropsMenuPage().inst().unfile_from_zero_unfile_popup()
                    with allure.step("Check if new message will have In-Process state during unfiling action..."):
                        print(InboxPage().inst().get_message_status(message_element))
                        # assert InboxPage().inst().get_message_status(message_element) == "In-Process"
                with allure.step("Check if Pop-up UnFiling dialog is closed..."):
                    assert RightClickMenuPage().inst().check_if_rightclick_filing_dialog_window_is_opened() is False
                with allure.step("Checking if Task Pane is Opened - Should be Opened!..."):
                    assert TaskPanePage().inst().is_opened() is True
        with allure.step("Waiting until new message will not have Unfiled state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Unfiled"):
                print("Filing status is grabbed...")
                with allure.step("Check that the state of new mail is not a Filed..."):
                    assert InboxPage().inst().get_message_status(message_element) != "Filed"
                with allure.step("Right Click on new message..."):
                    InboxPage().inst().open_right_click_props_menu(message_element)
                with allure.step("Check if Zero UnFile pop-up menu item is disabled..."):
                    assert RightClickPropsMenuPage().inst().check_zero_unfile_state() is False
                    message_element.click()
