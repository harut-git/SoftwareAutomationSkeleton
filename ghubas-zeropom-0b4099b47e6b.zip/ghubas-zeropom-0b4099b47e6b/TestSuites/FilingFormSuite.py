import time

import allure

from Base.BaseSuite import BaseSuite
from Pages.InboxPage import InboxPage
from Pages.RibbonPage import RibbonPage
from Pages.TaskPanePage import TaskPanePage


class FilingFormSuite(BaseSuite):

    def test_check_that_filing_form_subject_corresponds_to_TOE_subject(self):
        """ ZO-736 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with no prediction..."):
            message_element = InboxPage.inst().have_message_with_no_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Comparing Subjects..."):
            assert TaskPanePage.inst().get_subject().text == InboxPage.inst().get_message_subject(message_element)

    def test_check_that_filing_form_subject_is_editable(self):
        """ ZO-737, ZO-670 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with no prediction..."):
            message_element = InboxPage.inst().have_message_with_no_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Checking if subject is editable"):
            subject = TaskPanePage.inst().get_subject()
            subject_text = subject.text
            subject.clear()
            subject.send_keys("test")
            assert subject.text == "test"
            subject.clear()
            subject.send_keys(subject_text)

    def test_check_that_selected_matter_updates_client_lists_correctly(self):
        """ ZO-739 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with no prediction..."):
            message_element = InboxPage.inst().have_message_with_no_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Set a matter value"):
            assert TaskPanePage.inst().set_attribute_value("Matter", "111") is not None
        with allure.step("Chicking if parent child is set correctly..."):
            assert TaskPanePage.inst().get_attribute_value("Client") == "001 - Client 1"

    def test_check_that_any_attribute_values_are_sorted_in_ascending_order(self):
        """ ZO-740 """
        attribute_values_list = []
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_never_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Open client attribute's value list"):
            attr_field = TaskPanePage.inst().get_attribute_field("Client")
            search_results = TaskPanePage.inst().get_attribute_all_results(attr_field)
            for i in search_results:
                attribute_values_list.append(i.get_attribute("Name"))
        with allure.step("Checking if list is in ascending order"):
            print(attribute_values_list)
            assert sorted(attribute_values_list) == attribute_values_list

    def test_check_once_used_value_appears_in_recent_group(self):
        """ ZO-741 """
        attribute_values_list = []
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with never prediction..."):
            message_element = InboxPage.inst().have_message_with_never_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Set a matter value"):
            assert TaskPanePage.inst().set_attribute_value("Matter", "333") is not None
        with allure.step("Recent checkbox On..."):
            TaskPanePage.inst().check_add_to_recent()
        with allure.step("File message..."):
            TaskPanePage.inst().click_file_button()
        with allure.step("Waiting file process..."):
            assert InboxPage.inst().wait_for_element_status(message_element, "Filed") is True
        with allure.step("Getting a new smtp message with never prediction..."):
            new_message_element = InboxPage.inst().have_message_with_never_prediction()
            assert new_message_element is not False
            with allure.step("Clicking on new message..."):
                new_message_element.click()
                time.sleep(5)
        with allure.step("Open matter attribute's value list..."):
            new_attr_field = TaskPanePage.inst().get_attribute_field("Matter")
            search_results = TaskPanePage.inst().get_attribute_recent_results(new_attr_field)
            for i in search_results:
                attribute_values_list.append(i.get_attribute("Name"))
            print(attribute_values_list)
            assert any(item.startswith('333') for item in attribute_values_list) is True

    def test_check_that_it_is_possible_to_search_in_the_field_by_attribute_key_or_value(self):
        """ ZO-742, ZO-743 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with no prediction..."):
            message_element = InboxPage.inst().have_message_with_no_prediction()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Set a matter value by key"):
            assert TaskPanePage.inst().set_attribute_value("Matter", "443") is not None
        with allure.step("Checking if parent child is set correctly..."):
            assert TaskPanePage.inst().get_attribute_value("Matter").startswith('443')
        with allure.step("Set a matter value by Matter Name"):
            assert TaskPanePage.inst().set_attribute_value("Matter", "Matter 443") is not None
        with allure.step("Checking if parent child is set correctly..."):
            assert TaskPanePage.inst().get_attribute_value("Matter").startswith('443')
