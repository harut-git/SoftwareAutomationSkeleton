import time

import allure

from Base.BaseSuite import BaseSuite
from Pages.FilingLogPage import FilingLogPage
from Pages.InboxPage import InboxPage
from Pages.InspectorPage import InspectorPage
from Pages.RibbonPage import RibbonPage
from Pages.TaskPanePage import TaskPanePage


class FilingLogSuite(BaseSuite):
    def test_check_that_when_clicking_filing_log_button_filing_log_screen_opens(self):
        """ ZO-847 """
        # login()
        with allure.step("Waiting for up to date... "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening filing log... "):
            RibbonPage().inst().open_filing_log()
        with allure.step("Filing Log is opened"):
            assert FilingLogPage().inst().filinglog_is_opened() is True
        with allure.step("Closing Filing Log"):
            FilingLogPage.inst().close_filinglog_dialog()

    def test_check_that_filed_destination_in_taskpane_is_similar_to_destination_in_filing_log(self):
        """ ZO-848, ZO-854 """
        # login()
        with allure.step("Waiting for up to date... "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp message with one prediction..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
        time.sleep(3)
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
        with allure.step("Closing and opening Task Pane..."):
            TaskPanePage.inst().close_task_pane()
            time.sleep(5)
            RibbonPage.inst().open_task_pane()
        with allure.step("Getting filed message destination from TaskPane..."):
            filing_dest_from_taskpane = TaskPanePage.inst().get_filed_message_destination()
            print("Filed message destination is" + filing_dest_from_taskpane)
        with allure.step("Opening Filing Log..."):
            RibbonPage.inst().open_filing_log()
            time.sleep(5)
        with allure.step("Scrolling to find filed email by subject..."):
            filed_message_subject = InboxPage.inst().get_message_subject(message_element)
            FilingLogPage.inst().scroll_to_find_message_by_subject(filed_message_subject)
        with allure.step("Getting filed email destination from Filing Log..."):
            filing_dest_from_filinglog = FilingLogPage().inst().get_destination_of_filed_email()
            print("Filed message destination in Filing Log is" + filing_dest_from_filinglog)
        with allure.step("Comparing destinations..."):
            assert filing_dest_from_filinglog == filing_dest_from_taskpane
        with allure.step("Closing Filing Log..."):
            FilingLogPage().inst().close_filinglog_dialog()

    # def test_check_that_sender_subject_sent_and_file_dates_of_filed_email_in_taskpane_is_similar_to_all_of_those_in_filing_log(self):
    #     """ ZO-851 """
    #     login()
    # RibbonPage().inst().waiting_for_addin_status()
    # message_element = InboxPage.inst().have_message_with_ready_to_file()
    # message_element.click()
    # list_of_email_data = InboxPage.inst().get_message_data(message_element)
    # if not TaskPanePage.inst().is_opened():
    #     RibbonPage.inst().open_task_pane()
    # time.sleep(2)
    # TaskPanePage.inst().quickfile_higher_weight()
    # time.sleep(5)
    # RibbonPage.inst().open_filing_log()
    # list_of_filed_email_data = FilingLogPage().inst().filinglog_dialog_from_datagrid_get_email_subject_sender_sent_and_filed_dates()
    # for i in range(len(list_of_email_data)):
    #     assert list_of_email_data[i] == list_of_filed_email_data[i]
    # FilingLogPage().inst().close_filinglog_dialog()

    def test_check_that_autofiled_email_has_checked_state_in_filing_log(self):
        """ ZO-850 """
        # login()
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Getting an smtp conversation with one prediction..."):
            conversation_message = InboxPage().inst().have_ready_to_file_conversation()
            with allure.step("Clicking on new conversation..."):
                conversation_message.click()
        with allure.step("Opening Task Pane... "):
            RibbonPage.inst().open_task_pane()
        time.sleep(3)
        with allure.step("Quickfiling selected conversation with higher weight and Autofile option ON... "):
            assert TaskPanePage.inst().quickfile_higher_weight(autofile=True) is True
        with allure.step("Opening Filing Log... "):
            RibbonPage().inst().open_filing_log()
        with allure.step("Closing and opening Filing Log..."):
            FilingLogPage.inst().close_filinglog_dialog()
            time.sleep(10)
            RibbonPage.inst().open_filing_log()
        with allure.step("Scrolling to find filed email by subject..."):
            conversation_message_subject = InboxPage.inst().get_message_subject(conversation_message)
            FilingLogPage.inst().scroll_to_find_message_by_subject(conversation_message_subject)
        with allure.step("Checking that autofile checkbox state is ON "):
            assert FilingLogPage().inst().get_autofile_checkbox_status_from_last_message() is True
        with allure.step("Closing Filing Log... "):
            FilingLogPage().inst().close_filinglog_dialog()

    def test_check_if_subject_in_filing_log_is_similar_to_subject_in_Inspector_view(self):
        """ ZO-849 """
        # login()
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Opening Filing Log... "):
            RibbonPage().inst().open_filing_log()
        with allure.step("Getting a subject from filed email..."):
            subject_from_datagrid = FilingLogPage().inst().filinglog_dialog_from_datagrid_get_email_subject()
        with allure.step("Opening Inspector view by double click..."):
            FilingLogPage().inst().filinglog_dialog_open_filed_email_by_double_click()
        with allure.step("Getting subject from Inspector view..."):
            subject_from_inspector_window = InspectorPage().inst().inspector_get_subject_of_filed_email()
        with allure.step("Comparing subjects"):
            assert (subject_from_datagrid == subject_from_inspector_window) is True
    #
    # def test_check_that_unfiling_from_Filing_log_works_correctly(self):
    #     """ ZO-847, ZO-853, ZO-855, ZO-858 """
    #     login()
        # with allure.step("Waiting for up to date "):
        #     RibbonPage.inst().waiting_for_up_to_date_status()
        # with allure.step("Opening Filing Log... "):
        #     RibbonPage().inst().open_filing_log()
        # FilingLogPage().inst().filinglog_dialog_unfile_filed_email()
        # FilingLogPage().inst().close_filinglog_dialog()

