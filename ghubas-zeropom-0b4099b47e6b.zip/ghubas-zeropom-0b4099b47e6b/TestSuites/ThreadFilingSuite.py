import time

import allure

from Base.BaseSuite import BaseSuite
from Pages.InboxPage import InboxPage
from Pages.InspectorPage import InspectorPage
from Pages.RibbonPage import RibbonPage
from Pages.RightClickMenuPage import RightClickMenuPage
from Pages.RightClickPropsMenuPage import RightClickPropsMenuPage
from Pages.TaskPanePage import TaskPanePage


class ThreadFilingSuite(BaseSuite):

    def test_check_states_of_emails_in_thread_while_quickfile_one_ready_to_file_email_with_one_pred_from_inside(self):
        """ ZO-1073 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(4)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread_to_the_same_sender() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"

    def test_check_states_of_emails_in_thread_while_file_one_not_filed_email_with_diff_attrs_from_inside(self):
        """ ZO-1074 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(4)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Clicking on Choose Different Attributes button "):
            assert TaskPanePage().inst().click_on_choose_diff_attrs_button() is True
        with allure.step("Choose Different Matter Attribute for filing operation "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="551") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "No Filing"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Check that the state of the newest mail in a thread has Filed status..."):
            assert InboxPage().inst().get_message_status(message_element) == "Filed"

    def test_check_states_of_emails_in_thread_while_refile_one_filed_email_from_inside(self):
        """ ZO-1076 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Having ready to file conversation..."):
            message_element = InboxPage.inst().have_ready_to_file_conversation()
            time.sleep(4)
            assert message_element is not False
        with allure.step("Clicking on new conversation thread and enter inside of message list..."):
            assert InboxPage().inst().get_first_message_from_conversation() is True
        with allure.step("Clicking on first message..."):
            message_element = InboxPage().inst().get_first_message()
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Reply pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_reply()
        with allure.step("Replying to the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_reply_to_email_from_thread() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Right Click on new message..."):
            InboxPage().inst().open_right_click_props_menu(message_element)
        with allure.step("Click on Forward pop-up menu item..."):
            RightClickPropsMenuPage().inst().click_right_click_menu_forward()
        with allure.step("Forwarding the mail in conversation thread..."):
            assert InspectorPage().inst().inspector_forward_the_email_from_thread_to_the_same_sender() is True
        with allure.step("Sending new email from Composer..."):
            assert InspectorPage().inst().inspector_send_new_email() is True
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)
        with allure.step("Checking that Autofile checkbox state is OFF "):
            assert TaskPanePage().inst().get_auto_file_checkbox_state() is False
        with allure.step("Quickfile selected message from Task Pane with first prediction"):
            assert TaskPanePage.inst().quickfile_higher_weight() is True
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+2]
            message_element.click()
        with allure.step("Click on Re-File button "):
            assert TaskPanePage().inst().re_file_message() is True
        with allure.step("Click on Re-File button "):
            assert TaskPanePage().inst().re_file_dialog() is True
        with allure.step("Choose Different Matter Attribute for filing operation "):
            assert RightClickMenuPage().inst().set_attribute_value_into_rightclick_filing_dialog_window("Matter",
                                                                                                        value="551") is True
            time.sleep(2)
        with allure.step("File selected message from Task Pane with new attributes "):
            assert TaskPanePage.inst().click_file_button() is True
            time.sleep(2)
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[+1]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"
        with allure.step("Clicking on second message..."):
            message_element = InboxPage().inst().get_message_list()[0]
            message_element.click()
        with allure.step("Waiting until new message will not have Filed state..."):
            if InboxPage().inst().wait_for_element_status(message_element, "Ready to file"):
                print("Filing status is grabbed...")
        with allure.step("Check that the state of new mail is Ready to file..."):
            assert InboxPage().inst().get_message_status(message_element) == "Ready to file"
