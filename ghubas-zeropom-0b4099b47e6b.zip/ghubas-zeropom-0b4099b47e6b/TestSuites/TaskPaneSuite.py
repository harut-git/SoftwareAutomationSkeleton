import time

import allure

from Base.BaseSuite import BaseSuite
from Pages.InboxPage import InboxPage
from Pages.RibbonPage import RibbonPage
from Pages.TaskPanePage import TaskPanePage
from Utils.CabinetProfiles import rmkb_replicated


class TaskPaneSuite(BaseSuite):
    FILING_STATUSES = ['Unfiled', 'Filed', 'No Filing']

    def test_check_task_pane_content_corresponds_status(self):
        """ ZO-775 """
        RibbonPage().inst().waiting_for_up_to_date_status()
        RibbonPage.inst().open_task_pane()
        for i in self.FILING_STATUSES:
            found_element = InboxPage.inst().find_message_by_status(i)
            if found_element:
                found_element.click()
                print("------------------------------------clicked on " + i)
                print(TaskPanePage.inst().check_taskpane_state(i))
            else:
                print("Not Found status " + i)

    def test_check_that_Task_pane_is_updating_while_navigating_inbox_messages(self):
        """ ZO-777"""
        RibbonPage().inst().waiting_for_up_to_date_status()
        if not TaskPanePage.inst().is_opened():
            RibbonPage.inst().open_task_pane()
        message_list = InboxPage.inst().get_visible_messages()
        if not message_list:
            print("No messages in Inbox")
            return False
        if len(message_list) > 5:
            for i in range(5):
                message_list[i].click()
                current_message_status = InboxPage.inst().get_message_status(message_list[i])
                assert TaskPanePage.inst().check_taskpane_state(current_message_status) is True
        else:
            for i in message_list:
                message_list[i].click()
                current_message_status = InboxPage.inst().get_message_status(i)
                assert TaskPanePage.inst().check_taskpane_state(current_message_status) is True

    def test_check_that_task_pane_is_opening_when_clicking_on_No_Filing_statused_email(self):
        """ ZO-779 """
        RibbonPage().inst().waiting_for_up_to_date_status()
        if TaskPanePage.inst().is_opened():
            TaskPanePage.inst().close_task_pane()
            time.sleep(2)
        current_message_element = InboxPage.inst().get_first_message()
        if not InboxPage.inst().get_message_status(current_message_element) == "No Filing":
            current_message_element = InboxPage.inst().have_message_with_no_prediction()
        current_message_element.click()
        RibbonPage.inst().open_task_pane()
        time.sleep(2)
        assert TaskPanePage.inst().is_opened() is True

    def test_check_that_attributes_list_corresponds_to_cabinets_list(self):
        """ ZO-780 """
        RibbonPage().inst().waiting_for_up_to_date_status()
        current_element = InboxPage.inst().get_first_message()
        if not InboxPage.inst().get_message_status(current_element) == "No Filing":
            current_element = InboxPage.inst().have_message_with_no_prediction()
        current_element.click()
        if not TaskPanePage.inst().is_opened():
            RibbonPage.inst().open_task_pane()
        attr_list = TaskPanePage.inst().get_attributes_list()
        for i in attr_list:
            print(i.get_attribute("Name"))
            assert i.get_attribute("Name") in rmkb_replicated

    def test_check_that_for_filed_message_Taskpane_shows_filed_status_view(self):
        """ ZO-790 """
        RibbonPage().inst().waiting_for_up_to_date_status()
        current_message = InboxPage.inst().have_filed_message()
        current_message.click()
        assert TaskPanePage.inst().check_taskpane_state("Filed") is True

    def test_check_that_after_refiling_Taskpane_shows_filed_status_view(self):
        """ ZO-792 """
        with allure.step("Waiting for up to date "):
            RibbonPage.inst().waiting_for_up_to_date_status()
        with allure.step("Making a filed message and clicking on it..."):
            message_element = InboxPage.inst().have_message_with_ready_to_file()
            message_element = InboxPage.inst().set_message_status(message_element, "Filed")
            assert message_element is not False
            with allure.step("Clicking on new message..."):
                message_element.click()
        with allure.step("Opening Task Pane..."):
            RibbonPage.inst().open_task_pane()
            time.sleep(2)