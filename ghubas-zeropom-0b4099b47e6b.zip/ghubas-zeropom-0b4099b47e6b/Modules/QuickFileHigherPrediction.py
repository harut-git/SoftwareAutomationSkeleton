from Pages.RibbonPage import RibbonPage
from Pages.TaskPanePage import TaskPanePage


def quick_file_higher_prediction():
    if TaskPanePage.inst().is_opened():
        TaskPanePage.inst().quickfile_higher_weight()
    else:
        RibbonPage.inst().open_task_pane()
        TaskPanePage.inst().quickfile_higher_weight()

