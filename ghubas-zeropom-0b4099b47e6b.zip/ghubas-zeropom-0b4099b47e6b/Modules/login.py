import time

import win32serviceutil

from Pages.AddinsPage import AddinsPage
from Utils.RegistryEditor import clean_restrictions
import subprocess


def login():
    # AddinsPage().inst().check_addin_visible()
    AddinsPage().inst().addin_login()
    AddinsPage().inst().nd_frame_login()