============ Git Commands ==============

eval `ssh-agent -s`
ssh-add ~/.ssh/zero


============ Suite Run Commmands =========

pytest --alluredir SmokeResults


============ Allure Serve Results Commands =========

allure serve SmokeResults


