import os

WINIUM_PATH = os.path.abspath("../../WiniumDriver/Winium.Desktop.Driver.exe")
OUTLOOK_PATH = "C:\\Program Files (x86)\\Microsoft Office\\root\\Office16\\OUTLOOK.exe"

# Custom Attributes

custom_attributes = [{"id": "128",
                      "name": "Orrik Client",
                      "readOnly": False,
                      "promptIfEmpty": True,
                      "linked": None,
                      "type": ""
                      },
                     {"id": "129",
                      "name": "Orrik Matter",
                      "readOnly": False,
                      "promptIfEmpty": True,
                      "linked": "1"
                      },
                     {"id": "130",
                      "name": "Orrik Author",
                      "readOnly": False,
                      "promptIfEmpty": True,
                      "linked": None
                      },
                     {"id": "131",
                      "name": "Orrik Practice Group",
                      "readOnly": False,
                      "promptIfEmpty": True,
                      "linked": None
                      },
                     {"id": "132",
                      "name": "Orrik Document Type",
                      "readOnly": False,
                      "promptIfEmpty": True,
                      "linked": None
                      },
                     {"id": "133",
                      "name": "Orrik Document Status",
                      "readOnly": False,
                      "promptIfEmpty": True,
                      "linked": None
                      },
                     {"id": "134",
                      "name": "Orrik Comments",
                      "readOnly": False,
                      "promptIfEmpty": True,
                      "linked": None
                      }]

# Top and Side Pane attributes

side_pane_attributes = ["128", "129", "130", "131", "132"]
top_pane_attributes = ["128", "129"]
