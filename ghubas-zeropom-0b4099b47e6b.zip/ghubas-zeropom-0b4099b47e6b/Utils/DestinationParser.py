

def dest_parser(dest):
    k = dest.split("->")
    k[0] = k[0].replace(":*:", "-")
    k[0] = k[0].rstrip()
    k[1] = k[1].replace(":", "-")
    k[2] = k[2].replace(":", "-")
    k.append(k[2].split("_-_")[1])
    k[2] = k[2].split("_-_")[0]
    return k


print(len(range(1, 6)))
