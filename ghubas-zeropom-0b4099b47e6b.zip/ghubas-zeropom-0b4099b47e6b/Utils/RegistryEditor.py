import winreg

REG_PATH = r"Software\Zero\ZeroAddIn"
DISABLED_ITEMS_PATH = r"Software\Microsoft\Office\16.0\Outlook\Resiliency"
REG_AUTH_PATH = r"Software\Zero\OutlookAddin\Dmses\NetDocuments\AuthCredentials"


def set_reg(name, value):
    try:
        winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_PATH)
        registry_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0,
                                      winreg.KEY_WRITE)
        winreg.SetValueEx(registry_key, name, 0, winreg.REG_SZ, value)
        winreg.CloseKey(registry_key)
        return True
    except WindowsError:
        return False


def del_path(name):
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, DISABLED_ITEMS_PATH, 0, winreg.KEY_ALL_ACCESS)
        winreg.DeleteKey(key, name)
        return "Keys are removed"
    except WindowsError:
        return None


def del_reg(name, path):
    try:
        registry_key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0,
                                      winreg.KEY_ALL_ACCESS)
        winreg.DeleteValue(registry_key, name)
        return True
    except WindowsError:
        return None


def clean_restrictions():
    del_path("StartupItems")
    del_path('DisabledItems')
    del_reg('AccessToken', REG_AUTH_PATH)
    del_reg('RefreshToken', REG_AUTH_PATH)
    del_reg('TokenType', REG_AUTH_PATH)
    del_reg('TokenExpiresAt', REG_AUTH_PATH)
    return True

#del_path("DisabledItems")

# Example MouseSensitivity
# Read value
