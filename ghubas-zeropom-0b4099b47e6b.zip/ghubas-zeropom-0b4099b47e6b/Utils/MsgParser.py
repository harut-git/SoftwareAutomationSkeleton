import re


def parser(msg, key):
    if key == "FilingStatus":
        re_group = re.search('(?<=FilingStatus )Filed|Unfiled|In-Process|Error|Ready to file(?=,)', string=msg)
        if re_group is None:
            return None
        return re_group.group()
    elif key == "Subject":
        re_group = re.search('(?<=Subject )[\w,\s]+(?=,)', string=msg)
        if re_group is None:
            return None
        return re_group.group()
    elif key == "From":
        re_group = re.search('(?<=From )harutzeroapp@gmail.com|harutzeroapp2@gmail.com|Davit Siradeghyan(?=,)',
                             string=msg)
        if re_group is None:
            return None
        return re_group.group()


def parser_generic(msg, key):
    if key == "FilingStatus":
        re_group = re.search('(?<=FilingStatus )Filed|Unfiled|In-Process|Error|Ready to file(?=,)', string=msg)
        if re_group is None:
            return None
        return re_group.group()
    elif key == "From":
        re_group = re.search('(?<=From )+(.)+(?=, Subject)', string=msg)
        if re_group is None:
            return None
        return re_group.group()
    elif key == "Subject":
        re_group = re.search('(?<=Subject )+(.)+(?=, R)', string=msg)
        if re_group is None:
            return None
        return re_group.group()
    elif key == "Received":
        re_group = re.search('(?<=Received \w{3} )\d+\/\d+\/\d+(?= \d{1,2}\:\d{1,2} (PM|AM),)', string=msg)
        if re_group is None:
            return None
        return re_group.group()
    elif key == "Destination":
        re_group = re.search('(?<=Destination )(.*)(?=, Z)', string=msg)
        if re_group is None:
            return None
        return re_group.group()


msg_line = "From QA1 ZeroAppTest, Subject SMTP Test email from QA Test 1, Received Mon 3/4/2019 12:22 PM, Sent Mon 3/4/2019 12:22 PM, Size 64 KB, Destination Admin Client 1/Matter 100001, FilingStatus Filed, Flag Status Unflagged,"
msg_destination = parser_generic(msg_line, "Destination")
print(msg_destination)