import time
from multiprocessing import cpu_count, freeze_support
from multiprocessing.pool import Pool

from Utils.SmtpSender import send_message
from lorem import text

# Any results you write to the current directory are saved as output.

names = [None, 'Andrew McCartney', 'Mike Ross', 'Donna Paulsen', 'Daniel Whitehall']
# subjects = ['I was right - and that’s not good for you', '13 email marketing trends you must know', 'Before you write another blog post, read this', 'We’re starting in 5 HOURS', 'It’s time to rethink Black Friday', 'How to Google-proof your mobile site in 2017', ]
# inp = pd.read_csv('abcnews-date-text.csv')
# inp.head(3)
# text_model = markovify.NewlineText(inp.headline_text, state_size = 2)
# for i in range(5):
#     print(text_model.make_sentence())

accs = {
    'smithjjhn@gmail.com': ('John Smith', "ZeroApp#123"),
    'kleithkevin@gmail.com': ('Kevin Kleith', "ZeroApp#123"),
    'test1zeroapp@gmail.com': ('Andrew McCartney', "Test123321"),
    'test2zeroapp@gmail.com': ('Mike Ross', "Test123321"),
    'test3zeroapp@gmail.com': ('Donna Paulsen', "Test123321"),
    'test4zeroapp@gmail.com': ('Daniel Whitehall', "Test123321")
}


def prepare_data(test_account_id):
    sample = {
        "host": "smtp.gmail.com",
        "username": test_account_id,
        "password": accs[test_account_id][1],
        "subject": text_model.make_sentence(),
        "to": "shushanohanyan@zeroapp.ai",
        "from": accs[test_account_id][0],
        "text": text()
    }
    send_message(
        host=sample['host'],
        username=sample['username'],
        password=sample['password'],
        subject=sample['subject'],
        msg_to=sample['to'],
        msg_from=sample['from'],
        msg_text=sample['text']

    )


def prepare_data_for_accounts(contact_id):
    for i in range(50):
        prepare_data(contact_id)
        time.sleep(75)


def compile_all_async():
    pool = Pool(cpu_count())
    jobs = ['kleithkevin@gmail.com', 'smithjjhn@gmail.com', 'test1zeroapp@gmail.com', 'test2zeroapp@gmail.com', 'test3zeroapp@gmail.com', 'test4zeroapp@gmail.com']
    pool.map(prepare_data_for_accounts, jobs)


# if __name__ == '__main__':
#     freeze_support()
#     compile_all_async()
