import re
import subprocess

import psutil as psutil
import win32com.client


class Runner:
    def __init__(self, outlook_path=None, winium_path=None):
        self.outlook_path = outlook_path
        self.winium_path = winium_path
        self.current_outlook_process = None
        self.current_winium_process = None
        self.dispatched_app = None

    def start_outlook(self):
        try:
            if not self.dispatched_app:
                self.dispatched_app = win32com.client.Dispatch("Outlook.Application")
            self.current_outlook_process = subprocess.Popen(self.outlook_path)
            return self.current_outlook_process
        except WindowsError as e:
            print(e)
            return False

    def start_winium(self):
        try:
            self.current_winium_process = subprocess.Popen(self.winium_path)
            return self.current_winium_process
        except WindowsError as e:
            print(e)
            return False

    def close_outlook(self):
        for process in (process for process in psutil.process_iter() if process.name() == "OUTLOOK.EXE"):
            process.kill()
        return True

    def close_winium(self):
        if self.current_winium_process:
            return self.current_winium_process.kill()


def isprocessrunning(process):
    running = False
    s = subprocess.check_output('tasklist', shell=True)
    if process in s:
        running = True
    return running
