
# -- Mail Profiles -- #

one_prediction = {
    "host": "smtp.gmail.com",
    "username": "test1zeroapp@gmail.com",
    "password": "Test123321",
    "subject": "SMTP Test email with one prediction 2",
    "to": "outlook-qa-automate@zeroapp.ai",
    "from": "QA1 ZeroAppTest",
    "text": "Hello! SMTP new message for no prediction"
}

internal_no_prediction = {
    "host": "smtp.office365.com",
    "port": "587",
    "username": "qa@zeroapp.ai",
    "password": "InboxZero123",
    "subject": "SMTP Test internal email",
    "to": "outlook-qa-automate@zeroapp.ai",
    "from": "qa@zeroapp.ai",
    "text": "Hello! SMTP new internal message"
}

two_prediction = {
    "host": "mySMTP.server.com",
    "username": "mySMTP.server.com",
    "password": "mySMTP.server.com",
    "subject": "Test email from Python",
    "to": "mike@someAddress.org",
    "from": "python@mydomain.com",
    "text": "Python 3.4 rules them all!"
}

no_prediction = {
    "host": "smtp.gmail.com",
    "username": "harutzeroapp@gmail.com",
    "password": "Test123321",
    "subject": "SMTP Test email with no prediction",
    "to": "outlook-qa-automate@zeroapp.ai",
    "from": "harutzeroapp@gmail.com",
    "text": "Hello! SMTP new message for no prediction"
}

# send_message(host=no_prediction['host'],
#              username=no_prediction['username'],
#              password=no_prediction['password'],
#              subject=no_prediction['subject'],
#              msg_to=no_prediction['to'],
#              msg_from=no_prediction['from'],
#              msg_text=no_prediction['text'])


never_prediction = {
    "host": "smtp.gmail.com",
    "username": "poxoszeroapp@gmail.com",
    "password": "poxosik123",
    "subject": "Never prediction",
    "to": "outlook-qa-automate@zeroapp.ai",
    "from": "poxoszeroapp@gmail.com",
    "text": "Hello! SMTP new message for never prediction"
}

no_status_with_prediction = {
    "host": "smtp.gmail.com",
    "username": "gugushzeroapp@gmail.com",
    "password": "gugushik123",
    "subject": "Not filed with prediction",
    "to": "outlook-qa-automate@zeroapp.ai",
    "from": "poxoszeroapp@gmail.com",
    "text": "Hello! SMTP new message for no filing status with prediction"
}

multiple_emails = {
    "host": "smtp.gmail.com",
    "username": ["harutzeroapp2@gmail.com", "gugushzeroapp@gmail.com", "poxoszeroapp@gmail.com"],
    "password": ["Test123321", "gugushik123", "poxosik123"],
    "subject": "SMTP Test email in thread",
    "to": "outlook-qa-automate@zeroapp.ai",
    "from": ["harutzeroapp2@gmail.com", "gugushzeroapp@gmail.com", "poxoszeroapp@gmail.com"],
    "text": "Hello! SMTP new message in thread"
}
