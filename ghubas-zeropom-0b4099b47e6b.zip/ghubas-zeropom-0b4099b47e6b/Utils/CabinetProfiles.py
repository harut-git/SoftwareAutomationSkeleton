rmkb_replicated = ['ClientRmkb*', 'MatterRmkb*', 'AuthorRmkb*', 'Document TypeRmkb*', 'DescriptionRmkb',
                   'Legacy Doc IDRmkb']
