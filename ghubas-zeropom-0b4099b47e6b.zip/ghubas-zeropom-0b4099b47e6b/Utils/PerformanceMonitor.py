import datetime

from elasticsearch import Elasticsearch

es = Elasticsearch([{'host': '10.10.10.120', 'port': 9200}])
ts = datetime.datetime.today().strftime('%Y.%m.%d')


def get_metrics(timestamp):
    metrics = {}
    results = es.search(index="metricbeat-6.3.2-" + ts,
                        body={"query": {
                            "bool": {"must": [{"match": {"system.process.name": "OUTLOOK.EXE"}},
                                              {"match": {"@timestamp": timestamp}}]}}})
    print(results)
    metrics['memory'] = results['hits']['hits'][0]['_source']['system']['process']['memory']['rss']['bytes']
    metrics['cpu'] = results['hits']['hits'][0]['_source']['system']['process']['cpu']['total']['value']
    return metrics
