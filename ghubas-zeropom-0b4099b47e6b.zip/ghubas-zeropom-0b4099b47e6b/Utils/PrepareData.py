import errno
import json
import os
import win32com.client

# -- Static variables -- #

PR_SMTP_ADDRESS = "http://schemas.microsoft.com/mapi/proptag/0x39FE001E"

# outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
#
# inbox = outlook.GetDefaultFolder(6)
# data = inbox.parent.Folders("DATA")


def move_emails(from_folder, to_folder, count):
    current_emails_list = []
    items = from_folder.Items
    for i in range(1, items.Count+1):
        mm = items.Item(i)
        if len(current_emails_list) < count:
            k = mm.Copy()
            k.Save()
            print(k)
            current_emails_list.append(k)
        else:
            print(current_emails_list)
            break
    for j in current_emails_list:
        j.Move(to_folder)


def empty_inbox(inbox):
    items = inbox.Items
    for i in range(1, items.Count+1):
        inbox.Items.Remove(1)


# my_items = inbox.Items
# msg_list = []
# for j in range(1, my_items.Count+1):
#     f = my_items.Item(j)
#     msg_list.append(f)
# for k in msg_list:
#     k.Move(data.Folders(1))
# print(data.Folders(1))
# for i in range(1, data.Folders.Count+1):
#     print(str(data.Folders(i)) + "-" + str(i))
# my_items = inbox.Items
# f = my_items.GetLast()
# k = f.Copy()


def parse_folder(folder_obj, mail_quantity):
    messages = folder_obj.Items
    message = messages.GetLast()
    i = 0
    output_list = []
    while message:
        if message.Class == 43:
            subject = message.Subject
            destination = ''
            filing_status = ''
            for j in message.UserProperties:
                if j.Name == 'Destination':
                    destination = str(j)
                elif j.Name == 'FilingStatus':
                    filing_status = str(j)
            if message.SenderEmailType == "EX":
                sender = message.Sender.GetExchangeUser().PrimarySmtpAddress
            else:
                sender = message.SenderEmailAddress
            recipients = message.Recipients
            body = message.Body
            current_recipients = []
            for r in recipients:
                try:
                    k = r.AddressEntry.GetExchangeUser().PrimarySmtpAddress
                    current_recipients.append(k)
                except AttributeError:
                    k = r.PropertyAccessor.GetProperty(PR_SMTP_ADDRESS)
                    current_recipients.append(k)
            output_list.append({
                'subject': subject.encode("utf-8"),
                'from': sender,
                'recipients': current_recipients,
                'destination': destination,
                'filing_status': filing_status,
                'body': body.encode("utf-8")
            })
        i += 1

        message = messages.GetPrevious()
        if i > mail_quantity:
            break
    path = str(folder_obj.FolderPath).replace('\\', '/') + '.json'
    if path[:2] == '//':
        path = path[2:]
    final_path = 'Results' + '/' + path
    if not os.path.exists(os.path.dirname(final_path)):
        try:
            print(final_path)
            os.makedirs(os.path.dirname(final_path))
        except OSError as exc:  # Guard against race condition
            if exc.errno != errno.EEXIST:
                raise
    with open(final_path, "w+") as outfile:
        outfile.write(json.dumps(output_list))
    # data_json = json.dumps(output_list)
    # print type(data_json)
    # payload = {'json_payload': data_json}
    # r = requests.post('http://localhost:9092', data=payload)


def dig_folders(folder):
    parse_folder(folder, 100)
    if folder.Folders.Count > 0:
        for i in range(1, folder.Folders.Count + 1):
            dig_folders(folder.Folders(i))


# dig_folders(inbox)

# empty_inbox()