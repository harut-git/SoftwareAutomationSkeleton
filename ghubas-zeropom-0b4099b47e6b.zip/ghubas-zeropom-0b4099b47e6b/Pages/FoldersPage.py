from Base.BasePage import BasePage


class FoldersPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if FoldersPage.__instance is None:
            FoldersPage.__instance = FoldersPage()
        return FoldersPage.__instance

    # -- Elements -- #

    FOLDERS_PANE_SENT_ITEMS = "//*[(@ClassName='NetUIWBTreeDisplayNode') and (@Name='Sent Items')]"

    # -- Available Page Methods -- #

    def sent_items_pane(self):
        """ Entering into Sent Items TOE. """
        print("Entering into Sent Items TOE...")
        sent_items_pane_button = self.get_xpath(self.FOLDERS_PANE_SENT_ITEMS)
        sent_items_pane_button.click()
        return True