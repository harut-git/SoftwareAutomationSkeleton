import time

from Base.BasePage import BasePage


class RibbonPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if RibbonPage.__instance is None:
            RibbonPage.__instance = RibbonPage()
        return RibbonPage.__instance

    # -- Elements -- #

    RIBBON_GROUP = "//*[(@ClassName='NetUIChunk') and (@Name='Zero')]"
    FILE = 'File'
    ZERO_TEXT = 'Zero'
    RIBBON_ELEMENTS = 'NetUIRibbonButton'
    ZERO_REFRESH_BUTTON = 'Refresh'
    ZERO_SETTINGS_BUTTON = 'Settings'
    ZERO_FILINGLOG_BUTTON = 'Filing Log'
    ZERO_SETTINGS_LOGOUT_BUTTON = 'Logout'
    ZERO_SETTINGS_RADIOBUTTONS = ".//*[(@ClassName='RadioButton') and (@IsOffscreen='False')]"
    # ZERO_SETTINGS_AUTOFILEON_RADIOBUTTON_TEXT = "AutoFile ON"
    # ZERO_SETTINGS_AUTOFILEOFF_RADIOBUTTON_TEXT = "AutoFile OFF"
    # ZERO_SETTINGS_CLOSE_BUTTON = ".//*[(@AutomationId='Close') and (@IsOffscreen='False')]"
    ZERO_SETTINGS_CLOSE_BUTTON = "Close"
    ZERO_SETTINGS_APPLY_BUTTON = ".//*[(@AutomationId='Apply') and (@IsOffscreen='False')]"

    RESTART_OUTLOOK_BUTTON = 'Close Outlook'
    AVAILABLE_STATUSES = ['Syncing with NetDocuments     ', 'AI is calculating predictions',
                          "Everything is up to date      "]
    RIBBON_ACTIVE_BUTTONS = ".//*[(@ClassName='NetUIRibbonButton') and (@IsEnabled='True')]"
    RIBBON_COMPOSE_NEW_MAIL = "New Email"

    # -- Available Page Methods -- #

    def get_status(self):
        """ Returns current status of Zero-ND integration. """
        ribbon_group = self.wait_and_get_xpath(self.RIBBON_GROUP)
        return self.get_classnames_from_element(ribbon_group, self.RIBBON_ELEMENTS)[-1].get_attribute("Name").rstrip()

    def open_task_pane(self):
        """ Opens Task Pane from Ribbon by clicking File button or raises ElementNotFoundException for File button. """
        file_button = self.get_name(self.FILE)
        file_button.click()
        return True

    def click_on_refresh_button(self):
        """ Clicks on Refresh button from Ribbon. """
        refresh_button = self.wait_and_get_name(self.ZERO_REFRESH_BUTTON)
        refresh_button.click()
        return True

    def open_mail_composer(self):
        """ Opens Mail Composer from Ribbon by clicking on New Email button or raises ElementNotFoundException for File button. """
        compose_button = self.get_name(self.RIBBON_COMPOSE_NEW_MAIL)
        compose_button.click()
        return True

    def waiting_for_up_to_date_status(self):
        """ Waits for status to be Everything is up to date and returns True """
        up_to_date = False
        while not up_to_date:
            time.sleep(2)
            if RibbonPage.inst().get_status() == "Everything is up to date":
                up_to_date = True
                print("Status is - Everything is up to date!")
        return True

    def open_settings(self):
        """ Clicks Settings button in Outlook Add-in section. """
        settings_button = self.wait_and_get_name(self.ZERO_SETTINGS_BUTTON, 120)
        print(settings_button.get_attribute('Name') + ' is displayed')
        self.wait(5)
        settings_button.click()
        self.wait(5)
        print("SETTINGS IS CLICKED")
        return True

    def ribbon_settings_dialog_logout(self):
        """ Entering into Logout Dialog Window. """
        pane = self.get_name("Logout")
        settings_logout_button = pane.find_element_by_name(self.ZERO_SETTINGS_LOGOUT_BUTTON)
        """ Clicks Logout button in Outlook Add-in section. """
        settings_logout_button.click()
        print("SETTINGS LOGOUT IS CLICKED")
        return True

    def ribbon_settings_dialog_check_if_autofileon_radiobutton_is_selected(self):
        """ Entering into Settings Dialog Window. """
        pane = self.get_name("Settings")
        settings_radiobuttons = self.get_xpaths_from_element(pane, self.ZERO_SETTINGS_RADIOBUTTONS)
        """ Check if AutoFile ON radio button is selected in Settings dialog. """
        return settings_radiobuttons[0].is_selected()

    def ribbon_settings_dialog_click_on_autofileon_radiobutton(self):
        """ Entering into Settings Dialog Window. """
        pane = self.get_name("Settings")
        settings_radiobuttons = self.get_xpaths_from_element(pane, self.ZERO_SETTINGS_RADIOBUTTONS)
        settings_apply_button = self.get_xpath_from_element(pane, self.ZERO_SETTINGS_APPLY_BUTTON)
        """ Clicks AutoFile ON radio button in Settings dialog. """
        print("AutoFile ON radio button is clicked")
        settings_radiobuttons[0].click()
        print("Apply button is clicked to save the changes")
        settings_apply_button.click()
        return True

    def ribbon_settings_dialog_check_if_autofileoff_radiobutton_is_selected(self):
        """ Entering into Settings Dialog Window. """
        pane = self.get_name("Settings")
        settings_radiobuttons = self.get_xpaths_from_element(pane, self.ZERO_SETTINGS_RADIOBUTTONS)
        """ Check if AutoFile OFF radio button is selected in Settings dialog. """
        return settings_radiobuttons[1].is_selected()

    def ribbon_settings_dialog_click_on_autofileoff_radiobutton(self):
        """ Entering into Settings Dialog Window. """
        pane = self.get_name("Settings")
        settings_radiobuttons = self.get_xpaths_from_element(pane, self.ZERO_SETTINGS_RADIOBUTTONS)
        settings_apply_button = self.get_xpath_from_element(pane, self.ZERO_SETTINGS_APPLY_BUTTON)
        """ Clicks AutoFile OFF radio button in Settings dialog. """
        print("AutoFile OFF radio button is clicked")
        settings_radiobuttons[1].click()
        print("Apply button is clicked to save the changes")
        settings_apply_button.click()
        return True

    def restart_outlook(self):
        """ Entering into Logout Dialog Window. """
        pane = self.get_name("Zero logout")
        close_outlook_button = pane.find_element_by_name(self.RESTART_OUTLOOK_BUTTON)
        """ Clicks Close button in Restart Dialog. """
        close_outlook_button.click()
        print("CLOSE IS CLICKED")
        return True

    def open_filing_log(self):
        """ Clicks Filing Log button in Ribbon and returns True. """
        filing_log_button = self.wait_and_get_name(self.ZERO_FILINGLOG_BUTTON, 120)
        filing_log_button.click()
        return True

    def get_ribbon_active_buttons(self):
        """ Returns a list of ribbon active buttons. """
        group = self.get_name(self.ZERO_TEXT)
        return self.get_xpaths_from_element(group, self.RIBBON_ACTIVE_BUTTONS)

    def close_settings(self):
        """ Closes Settings dialog. """
        pane = self.get_name("Settings")
        close_settings_button = pane.find_element_by_name(self.ZERO_SETTINGS_CLOSE_BUTTON)
        close_settings_button.click()
        print("SETTINGS dialog IS CLOSED")
        return True
