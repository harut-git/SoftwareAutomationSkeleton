from selenium.common.exceptions import NoSuchElementException

from Base.BasePage import BasePage


class RightClickPropsMenuPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if RightClickPropsMenuPage.__instance is None:
            RightClickPropsMenuPage.__instance = RightClickPropsMenuPage()
        return RightClickPropsMenuPage.__instance

    # -- Elements -- #

    ZERO_FILE = "Zero File"
    ZERO_UNFILE = "Zero Unfile"
    UNFILE_EMAILS_WINDOW = "UnFile emails"
    UNFILE_EMAILS_TEXT = "When you UnFile emails, they are deleted from NetDocuments."
    UNFILE_EMAILS_DONT_ASK = "Don't ask again"
    UNFILE_EMAILS_CANCEL_ID = "Canel"
    UNFILE_EMAILS_UNFILE_BUTTON = "Unfile"
    RIGHT_CLICK_MENU_REPLY = "Reply"
    RIGHT_CLICK_MENU_FORWARD = "Forward"

    # -- Available Page Methods -- #

    def click_zero_file(self):
        """ Click File from props menu. """
        self.get_name(self.ZERO_FILE).click()

    def click_zero_unfile(self):
        """ Click Unfile from props menu. """
        self.get_name(self.ZERO_UNFILE).click()

    def check_zero_unfile_state(self):
        """ Check the state of Unfile from props menu. """
        return self.get_name(self.ZERO_UNFILE).is_enabled()

    def unfile_from_zero_unfile_popup(self):
        """ Unfiles from Unfile popup. """
        try:
            unfile_window = self.get_name(self.UNFILE_EMAILS_WINDOW)
            print("Window is displayed")
        except NoSuchElementException:
            print("Don't ask again mode on")
            return True
        self.get_name_from_element(unfile_window, self.UNFILE_EMAILS_TEXT)
        print("Warning text is displayed")
        self.get_name_from_element(unfile_window, self.UNFILE_EMAILS_DONT_ASK)
        print("Don't ask again is displayed")
        self.get_name_from_element(unfile_window, self.UNFILE_EMAILS_UNFILE_BUTTON).click()
        print("Unfile button clicked")

    def click_right_click_menu_reply(self):
        """ Click File from props menu. """
        self.get_name(self.RIGHT_CLICK_MENU_REPLY).click()

    def click_right_click_menu_forward(self):
        """ Click Unfile from props menu. """
        self.get_name(self.RIGHT_CLICK_MENU_FORWARD).click()
