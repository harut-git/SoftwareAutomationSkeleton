import time

import pyautogui

from Base.BasePage import BasePage
from Pages.Models import MessageElement
from Pages.RibbonPage import RibbonPage
from Pages.RightClickPropsMenuPage import RightClickPropsMenuPage
from Pages.TaskPanePage import TaskPanePage
from Utils.MsgParser import parser
from Utils.MsgParser import parser_generic
from Utils.SmtpProfiles import multiple_emails
from Utils.SmtpProfiles import one_prediction, internal_no_prediction, no_prediction, never_prediction
from Utils.SmtpSender import send_internal_message, send_message, sendReply


class InboxPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if InboxPage.__instance is None:
            InboxPage.__instance = InboxPage()
        return InboxPage.__instance

    # -- Static Variables -- #
    TEST_PROFILES = ['harutzeroapp@gmail.com', 'harutzeroapp2@gmail.com']

    # -- Elements -- #
    INBOX_MESSAGE_SORTED_CLASSNAME = "LeafRow"
    SCROLL_DOWN_NAME = "Line down"
    INBOX_LIST_MESSAGE = "ThreadItem"
    INBOX_LIST_CONVERSATION = "ThreadHeader"
    RIGHT_CLICK_PROPS_MENU = "NetUIPanViewer"
    INBOX_LIST_CONVERSATION_ARROW_CLASS = "GroupHeader"

    # -- Available Page Methods -- #

    def get_first_message(self):
        """ Returns the first message element from Inbox. """
        first_message = self.get_classname(self.INBOX_LIST_MESSAGE)
        return first_message

    def get_inbox_message_by_count(self, msg_number):
        """Returns message according to provided message number in Inbox"""
        msgs = self.get_classnames(self.INBOX_LIST_MESSAGE)
        return msgs[msg_number - 1]

    def get_message_params(self, msg_element):
        msg_line = msg_element.get_attribute("Name")
        print(msg_line)
        msg_status = parser_generic(msg_line, "FilingStatus")
        msg_from = parser_generic(msg_line, "From")
        msg_subject = parser_generic(msg_line, "Subject")
        msg_sent_date = parser_generic(msg_line, "Received")
        msg_destination = parser_generic(msg_line, "Destination")
        return MessageElement(
            msg_from=msg_from,
            msg_subject=msg_subject,
            msg_filed_date=None,
            msg_sent_date=msg_sent_date,
            msg_destination=msg_destination,
            msg_status=msg_status,
            msg_auto_filed=None
        )

    def get_message_list(self):
        """ Returns the second message element from Inbox. """
        messages = self.get_classnames(self.INBOX_LIST_MESSAGE)
        return messages

    def get_first_conversation(self):
        """ Returns first conversation element from Inbox. """
        first_conversation = self.get_classname(self.INBOX_LIST_CONVERSATION)
        return first_conversation

    def get_first_message_from_conversation(self):
        """ Returns first conversation element from Inbox. """
        first_conversation = self.get_classname(self.INBOX_LIST_CONVERSATION)
        first_conversation.click()
        pyautogui.press('enter')
        return True

    def get_expandable_element_of_first_conversation(self):
        """ Returns the arrow element t expand conversation elements from thread. """
        mail_thread_items = self.get_classnames(self.INBOX_LIST_CONVERSATION_ARROW_CLASS)
        return mail_thread_items
        # print(mail_thread_items)
        # for i in mail_thread_items:
        # if i.getText() == "Latest message shown. Expand to see previous items.":
        # if i.get_attribute("HelpText") == "Latest message shown. Expand to see previous items.":
        #     return i.parent
        # else:
        #     print("Element not found. Trying again.")

    def open_right_click_props_menu(self, message_element):
        """ Takes an element and performs right click, opens right click props menu. """
        self.right_click_element(message_element)

    def get_message_status(self, element):
        """ Takes an element and returns element's FilingStatus. """
        msg_line = element.get_attribute("Name")
        got_status = parser(msg_line, "FilingStatus")
        if got_status:
            return got_status.lstrip()
        else:
            return "No Filing"

    def get_message_subject(self, element):
        """ Takes an element and returns element's Subject. """
        msg_line = element.get_attribute("Name")
        got_subject = parser_generic(msg_line, "Subject")
        if got_subject:
            return got_subject.lstrip()
        else:
            return "No Subject Found"

    def get_message_data(self, element):
        """ Takes an element and returns element's Data. """
        msg_line = element.get_attribute("Name")
        got_status = parser_generic(msg_line, "FilingStatus")
        got_sender = parser_generic(msg_line, "From")
        got_subject = parser_generic(msg_line, "Subject")
        got_sent_date = parser_generic(msg_line, "Received")
        got_destination = parser_generic(msg_line, "Destination")
        email_data_list = []
        if got_status:
            email_data_list.append(got_status.lstrip())
        else:
            print("No Filing")
        if got_sender:
            email_data_list.append(got_sender.lstrip())
        else:
            print("No Sender Found")
        if got_subject:
            email_data_list.append(got_subject.lstrip())
        else:
            print("No Subject Found")
        if got_sent_date:
            email_data_list.append(got_sent_date.lstrip())
        else:
            print("No Sent Date Found")
        if got_destination:
            email_data_list.append(got_destination.lstrip())
        else:
            print("No Destination Found")

        # print(email_data_list)
        return email_data_list

    def navigate_emails(self):
        messages = self.get_classnames(self.INBOX_LIST_MESSAGE)
        for i in range(len(messages) - 1):
            messages[i].click()
            time.sleep(1)
            if not i == 0:
                messages[i - 1].click()
        return len(messages)

    def scroll_down(self, count):
        scroll_button = self.get_name(self.SCROLL_DOWN_NAME)
        for _ in range(count):
            scroll_button.click()

    def get_message_sender(self, element):
        msg_line = element.get_attribute("Name")
        got_sender = parser(msg_line, "From")
        if got_sender:
            return got_sender.lstrip()
        else:
            return "No Sender Found"

    def get_visible_messages(self):
        """ Returns message list that is visible in inbox. """
        return self.get_classnames(self.INBOX_LIST_MESSAGE)

    def find_message_by_status(self, status):
        """ Finds a message with given status or returns None."""
        messages = self.get_classnames(self.INBOX_LIST_MESSAGE)
        print("Found " + str(len(messages)) + " messages")
        if messages:
            for i in messages:
                if self.get_message_status(i) == status:
                    return i
                else:
                    if self.get_message_sender(i) in self.TEST_PROFILES:
                        print(i.get_attribute("Name"))
                    else:
                        return self.set_message_status(i, status)
        print("No FilingStatus matches")
        return None

    def have_message_with_no_prediction(self):
        """ SMTP sends a message with no prediction state, checks if first message is sent one, returns it. """
        subject = never_prediction['subject'] + str(time.time())
        send_message(host=no_prediction['host'],
                     username=no_prediction['username'],
                     password=no_prediction['password'],
                     subject=subject,
                     msg_to=no_prediction['to'],
                     msg_from=no_prediction['from'],
                     msg_text=no_prediction['text'])
        time.sleep(5)
        new_message = False
        checks = 0
        while not new_message:
            checks += 1
            message_element = InboxPage.inst().get_first_message()
            time.sleep(5)
            if message_element.text == 'Message Unread' and InboxPage.inst().get_message_subject(message_element) \
                    == subject:
                return message_element
            elif checks >= 10:
                return None

    def have_message_with_ready_to_file(self):
        """ SMTP sends a message with ready to file status, checks if first message is sent one, returns it. """
        subject = one_prediction['subject'] + str(time.time())
        send_message(host=one_prediction['host'],
                     username=one_prediction['username'],
                     password=one_prediction['password'],
                     subject=subject,
                     msg_to=one_prediction['to'],
                     msg_from=one_prediction['from'],
                     msg_text=one_prediction['text'])
        time.sleep(5)
        new_message = False
        checks = 0
        while not new_message:
            checks += 1
            message_element = InboxPage.inst().get_first_message()
            time.sleep(5)
            if message_element.text == 'Message Unread' and InboxPage.inst().get_message_subject(message_element) \
                    == subject:
                return message_element
            elif checks >= 10:
                print("No new message received")
                return False

    def have_internal_message(self):
        """ SMTP sends a message with ready to file status, checks if first message is sent one, returns it. """
        subject = internal_no_prediction['subject'] + str(time.time())
        send_internal_message(host=internal_no_prediction['host'],
                              username=internal_no_prediction['username'],
                              password=internal_no_prediction['password'],
                              subject=subject,
                              msg_to=internal_no_prediction['to'],
                              msg_from=internal_no_prediction['from'],
                              msg_text=internal_no_prediction['text'],
                              smtp_port=internal_no_prediction['port'])
        time.sleep(5)
        new_message = False
        checks = 0
        while not new_message:
            checks += 1
            message_element = InboxPage.inst().get_first_message()
            time.sleep(5)
            if message_element.text == 'Message Unread' and InboxPage.inst().get_message_subject(message_element) \
                    == subject:
                return message_element
            elif checks >= 10:
                print("No new message received")
                return False

    def have_message_with_never_prediction(self):
        """ SMTP sends a message with ready to file status, checks if first message is sent one, returns it. """
        subject = never_prediction['subject'] + str(time.time())
        send_message(host=never_prediction['host'],
                     username=never_prediction['username'],
                     password=never_prediction['password'],
                     subject=subject,
                     msg_to=never_prediction['to'],
                     msg_from=never_prediction['from'],
                     msg_text=never_prediction['text'])
        time.sleep(5)
        new_message = False
        checks = 0
        while not new_message:
            checks += 1
            message_element = InboxPage.inst().get_first_message()
            time.sleep(5)
            if message_element.text == 'Message Unread' and InboxPage.inst().get_message_subject(message_element) \
                    == subject:
                return message_element
            elif checks >= 10:
                print("No new message received")
                return False

    def have_ready_to_file_conversation(self):
        """ SMTP sends a message with ready to file status, then sends a reply by the same message id, checks if
        first conversation is sent one, returns it. """
        subject = one_prediction['subject'] + str(time.time())
        msg_id = send_message(host=one_prediction['host'],
                              username=one_prediction['username'],
                              password=one_prediction['password'],
                              subject=subject,
                              msg_to=one_prediction['to'],
                              msg_from=one_prediction['from'],
                              msg_text=one_prediction['text'])
        time.sleep(5)
        sendReply(host=one_prediction['host'],
                  username=one_prediction['username'],
                  password=one_prediction['password'],
                  subject=subject,
                  msg_to=one_prediction['to'],
                  msg_from=one_prediction['from'],
                  msg_text=one_prediction['text'],
                  msg_id=msg_id)
        time.sleep(5)
        new_conversation = False
        checks = 0
        while not new_conversation:
            checks += 1
            conversation_element = InboxPage.inst().get_first_conversation()
            time.sleep(5)
            if conversation_element.text == 'Message Unread' and InboxPage.inst().get_message_subject(
                    conversation_element) == subject:
                conversation_element.click()
                return conversation_element
            elif checks >= 10:
                return "No new conversation received"

    def have_various_status_conversation(self):
        """ SMTP sends a message with ready to file status, then sends a reply by the same message id, checks if
        first conversation is sent one, returns it. After that send message with no prediction and reply to it. """
        subject = one_prediction['subject'] + str(time.time())
        msg_id = send_message(host=multiple_emails['host'],
                              username=multiple_emails['username'],
                              password=multiple_emails['password'],
                              subject=subject,
                              msg_to=multiple_emails['to'],
                              msg_from=multiple_emails['from'],
                              msg_text=multiple_emails['text'])
        time.sleep(5)
        sendReply(host=multiple_emails['host'],
                  username=multiple_emails['username'],
                  password=multiple_emails['password'],
                  subject=subject,
                  msg_to=multiple_emails['to'],
                  msg_from=multiple_emails['from'],
                  msg_text=multiple_emails['text'],
                  msg_id=msg_id)
        time.sleep(5)
        new_conversation = False
        checks = 0
        while not new_conversation:
            checks += 1
            conversation_element = InboxPage.inst().get_first_conversation()
            time.sleep(5)
            if conversation_element.text == 'Message Unread' and InboxPage.inst().get_message_subject(
                    conversation_element) == subject:
                conversation_element.click()
                return conversation_element
            elif checks >= 10:
                return "No new conversation received"

    def wait_for_element_status(self, message_element, status, wait=30):
        loading_process = True
        checks = 0
        while loading_process:
            checks += 1
            time.sleep(5)
            if InboxPage.inst().get_message_status(message_element) == status:
                loading_process = False
            elif checks > int(wait / 5):
                print("Message hasn't got specified status")
                return False
        return True

    def wait_for_element_status_generic(self, message_element, status, wait=15):
        loading_process = True
        checks = 0
        while loading_process:
            checks += 1
            time.sleep(5)
            if InboxPage.inst().get_message_data(message_element) == status:
                loading_process = False
            elif checks > int(wait / 3):
                print("Message has'nt got specified status")
                return False
        return True

    def have_filed_message(self):
        message_element = self.have_message_with_ready_to_file()
        message_element.click()
        if not TaskPanePage.inst().is_opened():
            RibbonPage.inst().open_task_pane()
        TaskPanePage.inst().quickfile_higher_weight()
        loading_process = True
        while loading_process:
            time.sleep(2)
            if self.get_message_status(message_element) == "Filed":
                loading_process = False
        return message_element

    def set_message_status(self, message_element, status):
        """ Takes an element as an argument, changes element status to given status. """
        element_status = self.get_message_status(message_element)
        if status == element_status:
            return "Statuses are matching"
        else:
            if status == "Filed":
                if element_status == "Ready to file":
                    message_element.click()
                    if not TaskPanePage.inst().is_opened():
                        RibbonPage.inst().open_task_pane()
                    TaskPanePage.inst().quickfile_higher_weight()

                elif element_status == "Unfiled" or element_status == "No Filing":
                    message_element.click()
                    if not TaskPanePage.inst().is_opened():
                        RibbonPage.inst().open_task_pane()
                    if TaskPanePage.inst().get_quick_file_buttons():
                        TaskPanePage.inst().quickfile_higher_weight()
                    else:
                        TaskPanePage.inst().random_file_no_predictions()

            elif status == "Unfiled":
                if not element_status == "Filed":
                    self.set_message_status(message_element, "Filed")
                message_element.click()
                if TaskPanePage.inst().is_opened():
                    TaskPanePage.inst().close_task_pane()
                RightClickPropsMenuPage.inst().unfile_from_zero_unfile_popup()
                self.open_right_click_props_menu(message_element)
                RightClickPropsMenuPage.inst().click_zero_unfile()
                time.sleep(2)
                RibbonPage.inst().open_task_pane()

            elif status == "No Filing":
                return self.have_message_with_no_prediction()
            elif status == 'Ready to file':
                return self.have_message_with_ready_to_file()

            loading_process = True
            while loading_process:
                time.sleep(2)
                if self.get_message_status(message_element) == status:
                    loading_process = False
            return message_element
