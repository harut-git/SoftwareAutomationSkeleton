from selenium.common.exceptions import TimeoutException

from Base.BasePage import BasePage


class OutlookWindowPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if OutlookWindowPage.__instance is None:
            OutlookWindowPage.__instance = OutlookWindowPage()
        return OutlookWindowPage.__instance

    # -- Elements -- #

    main_window = "Ribbon Tabs"
    inbox = "Inbox"

    # -- Available Page Methods -- #

    def outlook_is_opened(self):
        """ Checks if Ribbon bar is shown. Returns True if Outlook is opened or raises TimeoutException. """
        try:
            self.wait_and_get_name(self.inbox, wait_seconds=30)
        except TimeoutException:
            return False
        return True

    def outlook_is_running(self):
        import win32ui
        try:
            win32ui.FindWindow(None, "Microsoft Outlook")
            return True
        except win32ui.error:
            return False
