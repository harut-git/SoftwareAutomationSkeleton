class MessageElement:
    def __init__(self, msg_from, msg_subject, msg_sent_date, msg_destination, msg_filed_date, msg_auto_filed,
                 msg_status, filed_params=None):
        self.msg_from = msg_from
        self.msg_subject = msg_subject
        self.msg_sent_date = msg_sent_date
        self.msg_destination = msg_destination
        self.msg_filed_date = msg_filed_date
        self.msg_auto_filed = msg_auto_filed
        self.msg_status = msg_status


class CustomAttributes:
    def __init__(self, *args):
        for i in args:
            self.i = i
