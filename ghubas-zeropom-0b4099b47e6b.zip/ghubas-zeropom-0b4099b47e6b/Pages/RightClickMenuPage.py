from selenium.common.exceptions import NoSuchElementException

from Base.BasePage import BasePage


class RightClickMenuPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if RightClickMenuPage.__instance is None:
            RightClickMenuPage.__instance = RightClickMenuPage()
        return RightClickMenuPage.__instance

    # -- Elements -- #

    RIGHTCLICK_TASK_PANE = "TaskPane"
    RIGHTCLICK_LIST_BOX_CLASS = "TextBox"
    RIGHTCLICK_LAST_FILING_WINDOW_PREDICTION_CONTENT_CLASS = "TextBlock"
    RIGHTCLICK_LAST_FILING_WINDOW_PREDICTION_CONTENT = ".//*[(@ClassName='TextBlock') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_WINDOW = "Filing"
    RIGHTCLICK_LAST_FILING_WINDOW = "Last filing"
    # RIGHTCLICK_FILING_CLOSE_BUTTON = "Close"
    RIGHTCLICK_FILING_CLOSE_BUTTON = ".//*[(@AutomationId='Close') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_DETAILS_BUTTON = ".//*[(@AutomationId='ExpandDetails') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_LESS_BUTTON = ".//*[(@AutomationId='CollapseDetails') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_QUICKFILE_BUTTON = ".//*[(@AutomationId='QuickFile') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_FILE_BUTTON = ".//*[(@AutomationId='File') and (@IsOffscreen='False')]"
    # RIGHTCLICK_FILING_REFILE_BUTTON = ".//*[(@AutomationId='File') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_CHOOSE_DIFF_ATTR_BUTTON = ".//*[(@AutomationId='ChooseDifferentAttributes') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_REFILE_BUTTON = RIGHTCLICK_FILING_CHOOSE_DIFF_ATTR_BUTTON
    RIGHTCLICK_FILING_MOVE_TO_NEW_DEST_WINDOW_CLASS = "RefileConfirmationView"
    RIGHTCLICK_FILING_MOVE_TO_NEW_DEST_REFILE_BUTTON = "Refile"
    RIGHTCLICK_FILING_AUTOFILE_CHECKBOX = "AutoFile this conversation"
    RIGHTCLICK_FILING_AUTOFILE_OPTION_WINDOW_CLASS = "AutoFileConfirmationView"
    RIGHTCLICK_FILING_AUTOFILE_OPTION_OK_BUTTON = "OK"
    # RIGHTCLICK_FILING_ATTR_FIELD_XPATH = ".//*[(@AutomationId='AutosuggestBox') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_ATTR_FIELD_XPATH = ".//*[(@AutomationId='textBoxSearch') and (@IsOffscreen='False')]"
    # RIGHTCLICK_FILING_ATTR_FIELD_ID = "AutosuggestBox"
    RIGHTCLICK_FILING_ATTR_VALUE_ID = "textBoxSearch"
    RIGHTCLICK_FILING_ATTR_DROPDOWN = ".//*[(@ClassName='Button') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_ATTR_ITEM = ".//*[(@ClassName='TextBlock') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_ATTR_VALUE_LIST_ITEM_CLASSNAME = "ListBoxItem"
    RIGHTCLICK_FILING_ATTR_LIST_BOX_SEARCH_RESULTS = 'listBoxSearchResults'
    RIGHTCLICK_FILING_ATTR_LIST_BOX_SEARCH_GROUPS = "GroupItem"
    RIGHTCLICK_FILING_CLIENT = ".//*[(@Name='ClientRmkb*') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_MATTER = ".//*[(@Name='MatterRmkb*') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_AUTHOR = ".//*[(@Name='AuthorRmkb*') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_DOC_TYPE = ".//*[(@Name='Document TypeRmkb*') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_DESCRIPTION = ".//*[(@Name='DescriptionRmkb') and (@IsOffscreen='False')]"
    RIGHTCLICK_FILING_LEGACY_DOC_ID = ".//*[(@Name='Legacy Doc IDRmkb') and (@IsOffscreen='False')]"

    # -- Available Page Methods -- #

    def check_if_rightclick_filing_dialog_window_is_opened(self):
        """ Checks if RightClick Filing dialog window is opened. Returns True or raises TimeoutException. """
        try:
            self.get_classname(self.RIGHTCLICK_TASK_PANE)
            print("RightClick Filing dialog window is opened")
            self.get_name("Filing")
            print("RightClick Filing dialog window header text is visible")
            return True
        except NoSuchElementException:
            return False

    def rightclick_filing_dialog_window_click_on_details_button(self):
        """ Click on Details button into RightClick Filing dialog window. """
        rightclick_pane = self.get_name("Filing")
        rightclick_details_button = self.get_xpath_from_element(rightclick_pane, self.RIGHTCLICK_FILING_DETAILS_BUTTON)
        rightclick_details_button.click()
        return True

    def rightclick_filing_dialog_window_click_to_choose_diff_attr_button(self):
        """ Click to Choose the Different Attributes button into RightClick Filing dialog window. """
        rightclick_pane = self.get_name("Filing")
        rightclick_choose_diif_attr_button = self.get_xpath_from_element(rightclick_pane,
                                                                         self.RIGHTCLICK_FILING_CHOOSE_DIFF_ATTR_BUTTON)
        rightclick_choose_diif_attr_button.click()
        return True

    def rightclick_filing_dialog_window_click_on_less_button(self):
        """ Click on Less button into RightClick Filing dialog window. """
        rightclick_pane = self.get_name("Filing")
        rightclick_less_button = self.get_xpath_from_element(rightclick_pane, self.RIGHTCLICK_FILING_LESS_BUTTON)
        rightclick_less_button.click()
        return True

    def rightclick_filing_dialog_window_click_on_quickfile_button(self):
        """ Click on QuickFile button into RightClick Filing dialog window. """
        rightclick_pane = self.get_name("Filing")
        rightclick_quickfile_button = self.get_xpath_from_element(rightclick_pane,
                                                                  self.RIGHTCLICK_FILING_QUICKFILE_BUTTON)
        rightclick_quickfile_button.click()
        return True

    def rightclick_filing_dialog_window_click_on_file_button(self):
        """ Click on QuickFile button into RightClick Filing dialog window. """
        rightclick_pane = self.get_name("Filing")
        rightclick_file_button = self.get_xpath_from_element(rightclick_pane,
                                                             self.RIGHTCLICK_FILING_FILE_BUTTON)
        rightclick_file_button.click()
        return True

    def rightclick_last_filing_dialog_window_click_on_refile_button(self):
        """  Click on ReFile button into RightClick Filing dialog window.  """
        task_pane_element = self.get_classname(self.RIGHTCLICK_TASK_PANE)
        re_file_button = self.get_xpath_from_element(task_pane_element, self.RIGHTCLICK_FILING_REFILE_BUTTON)
        # assert re_file_button.get_attribute("Name") == "Refile"
        re_file_button.click()
        return True

    def rightclick_last_filing_dialog_window_get_autofile_checkbox_state(self):
        """ Check the state of AutoFile checkbox into RightClick Last Filing dialog window. """
        rightclick_pane = self.get_name("Last filing")
        return self.get_name_from_element(rightclick_pane, self.RIGHTCLICK_FILING_AUTOFILE_CHECKBOX).is_selected()

    def rightclick_last_filing_dialog_window_click_on_autofile_checkbox(self):
        """ Check the state of AutoFile checkbox into RightClick Last Filing dialog window. """
        rightclick_pane = self.get_name("Last filing")
        rightclick_autofile_checkbox = self.get_name_from_element(rightclick_pane,
                                                                  self.RIGHTCLICK_FILING_AUTOFILE_CHECKBOX)
        rightclick_autofile_checkbox.click()
        return True

    def close_rightclick_filing_dialog_window(self):
        """ Closes RightClick Filing dialog window by upper right corner X button. """
        rightclick_pane = self.get_name("Filing")
        rightclick_close_button = self.get_xpath_from_element(rightclick_pane, self.RIGHTCLICK_FILING_CLOSE_BUTTON)
        rightclick_close_button.click()
        return True

    def close_rightclick_last_filing_dialog_window(self):
        """ Closes RightClick Last Filing dialog window by upper right corner X button. """
        rightclick_pane = self.get_name("Last filing")
        rightclick_close_button = self.get_xpath_from_element(rightclick_pane, self.RIGHTCLICK_FILING_CLOSE_BUTTON)
        rightclick_close_button.click()
        return True

    def get_attributes_list_from_rightclick_filing_dialog_window(self):
        return [
            self.get_xpath_from_element(self.get_classname(self.RIGHTCLICK_TASK_PANE), self.RIGHTCLICK_FILING_CLIENT),
            self.get_xpath_from_element(self.get_classname(self.RIGHTCLICK_TASK_PANE), self.RIGHTCLICK_FILING_MATTER),
            self.get_xpath_from_element(self.get_classname(self.RIGHTCLICK_TASK_PANE), self.RIGHTCLICK_FILING_AUTHOR),
            self.get_xpath_from_element(self.get_classname(self.RIGHTCLICK_TASK_PANE), self.RIGHTCLICK_FILING_DOC_TYPE),
            self.get_xpath_from_element(self.get_classname(self.RIGHTCLICK_TASK_PANE), self.RIGHTCLICK_FILING_DESCRIPTION),
            self.get_xpath_from_element(self.get_classname(self.RIGHTCLICK_TASK_PANE), self.RIGHTCLICK_FILING_LEGACY_DOC_ID)
        ]

    def get_attribute_value_from_rightclick_filing_dialog_window(self, attribute_name):
        """ Takes attribute name and returns its value. """
        attribute_field = None
        task_pane_element = self.get_classname(self.RIGHTCLICK_TASK_PANE)
        attr_field_list = self.get_xpaths_from_element(task_pane_element, self.RIGHTCLICK_FILING_ATTR_FIELD_XPATH)
        if attribute_name == 'Client':
            attribute_field = attr_field_list[0]
        elif attribute_name == 'Matter':
            attribute_field = attr_field_list[1]
        elif attribute_name == 'Author':
            attribute_field = attr_field_list[2]
        elif attribute_name == 'Doctype':
            attribute_field = attr_field_list[3]
        else:
            return attribute_field
        # return self.get_id_from_element(attribute_field, self.RIGHTCLICK_FILING_ATTR_VALUE_ID).text

        return self.get_xpaths_from_element(task_pane_element, self.RIGHTCLICK_FILING_ATTR_FIELD_XPATH)

        # for i in self.get_xpaths_from_element(task_pane_element, self.RIGHTCLICK_FILING_ATTR_FIELD_XPATH):
        #     print i.text

        # list_box_elements = self.get_xpaths_from_element(task_pane_element, self.RIGHTCLICK_FILING_ATTR_FIELD_XPATH)
        # for i in range(len(list_box_elements)):
        #     print "The text for " + str(i) + "-th element is " + str(list_box_elements[i].text)

    def set_attribute_value_into_rightclick_filing_dialog_window(self, attribute_name, value=None):
        """ Takes attribute name, sets value and returns value if filled randomly. """
        attribute_field = None
        task_pane_element = self.get_classname(self.RIGHTCLICK_TASK_PANE)
        attr_field_list = self.get_xpaths_from_element(task_pane_element, self.RIGHTCLICK_FILING_ATTR_FIELD_XPATH)
        if attribute_name == 'Client':
            attribute_field = attr_field_list[0]
        elif attribute_name == 'Matter':
            attribute_field = attr_field_list[1]
        elif attribute_name == 'Author':
            attribute_field = attr_field_list[2]
        elif attribute_name == 'Doctype':
            attribute_field = attr_field_list[3]
        else:
            return attribute_field
        if not value:
            return self.set_random_attribute_value_into_rightclick_filing_dialog_window(attribute_field)
        return self.set_custom_attribute_value_into_rightclick_filing_dialog_window(attribute_field, value)

    def set_random_attribute_value_into_rightclick_filing_dialog_window(self, attr_field):
        """ Takes an attribute field, randomly fills it and returns value. """
        self.get_xpath_from_element(attr_field, self.RIGHTCLICK_FILING_ATTR_DROPDOWN).click()
        print("Search clicked")
        search_results = self.get_id(self.RIGHTCLICK_FILING_ATTR_LIST_BOX_SEARCH_RESULTS)
        print("Search opened")
        first_item = self.get_xpath_from_element(search_results, self.RIGHTCLICK_FILING_ATTR_ITEM)
        print("Item found")
        print(first_item)
        first_item.click()
        return self.get_id_from_element(attr_field, self.RIGHTCLICK_FILING_ATTR_VALUE_ID).text

    def set_custom_attribute_value_into_rightclick_filing_dialog_window(self, attr_field, value):
        attr_field.send_keys(value)
        search_results = self.get_id(self.RIGHTCLICK_FILING_ATTR_LIST_BOX_SEARCH_RESULTS)
        print("Search opened")
        first_item = self.get_xpath_from_element(search_results, self.RIGHTCLICK_FILING_ATTR_ITEM)
        first_item.click()
        return True

    def rightclick_filing_dialog_window_get_filed_content_data(self):
        """ Returns filed message content data. """
        content_data_list = []
        task_pane_element = self.get_classname(self.RIGHTCLICK_TASK_PANE)
        # return self.get_classnames_from_element(task_pane_element, self.RIGHTCLICK_LAST_FILING_WINDOW_PREDICTION_CONTENT_CLASS)
        for content_data_el in self.get_xpaths_from_element(task_pane_element, self.RIGHTCLICK_LAST_FILING_WINDOW_PREDICTION_CONTENT):
            # print content_data_el.get_attribute("Name")
            content_data_list.append(content_data_el.get_attribute("Name"))
        if not content_data_list:
            return True
        return False


    def rightclick_filing_dialog_window_move_to_new_destination_window_is_opened(self):
        """ Checks if Move to new destination dialog window is opened. Returns True or raises TimeoutException. """
        try:
            self.get_classname(self.RIGHTCLICK_FILING_MOVE_TO_NEW_DEST_WINDOW_CLASS)
            print("Move to new destination dialog window is opened")
            self.get_name("Move to new destination.")
            print("Move to new destination dialog window header text is visible")
            return True
        except NoSuchElementException:
            return False

    def rightclick_filing_dialog_window_move_to_new_destination_window_click_on_refile(self):
        """ Entering into Moving to new destination dialog window and Clicking on ReFile button. """
        pane = self.get_name("Move to new destination.")
        refile_button = pane.find_element_by_name(self.RIGHTCLICK_FILING_MOVE_TO_NEW_DEST_REFILE_BUTTON)
        refile_button.click()
        print("Moving to new destination...")
        return True

    def rightclick_filing_dialog_window_autofile_option_window_is_opened(self):
        """ Checks if AutoFile option dialog window is opened. Returns True or raises TimeoutException. """
        try:
            self.get_classname(self.RIGHTCLICK_FILING_AUTOFILE_OPTION_WINDOW_CLASS)
            print("AutoFile option dialog window is opened")
            self.get_name("AutoFile option")
            print("AutoFile option dialog window header text is visible")
            return True
        except NoSuchElementException:
            return False

    def rightclick_filing_dialog_window_autofile_option_window_click_on_ok(self):
        """ Entering into AutoFile option dialog window and Clicking on ReFile button. """
        pane = self.get_name("AutoFile option")
        refile_button = pane.find_element_by_name(self.RIGHTCLICK_FILING_AUTOFILE_OPTION_OK_BUTTON)
        refile_button.click()
        print("AutoFile option...")
        return True