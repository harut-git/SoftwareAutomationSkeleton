from selenium.common.exceptions import NoSuchElementException

from Base.BasePage import BasePage


class InspectorPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if InspectorPage.__instance is None:
            InspectorPage.__instance = InspectorPage()
        return InspectorPage.__instance

    # -- Elements -- #

    INSPECTOR_WINDOW_TITLE = "//*[(@ClassName='NetUIOfficeCaption') and (@ControlType='ControlType.TitleBar')]"
    INSPECTOR_WINDOW_CLOSE_BUTTON = "//*[(@ClassName='NetUIAppFrameHelper') and (@Name='Close')]"
    INSPECTOR_WINDOW_SEND_BUTTON = "//*[(@ClassName='Button') and (@Name='Send')]"
    INSPECTOR_EMAIL_DATA_CLASS = "RichEdit20WPT"
    INSPECTOR_EMAIL_DATA_OBJECTS_CLASS = "ControlType.Edit"
    INSPECTOR_EMAIL_DATA_SENDER = "//*[(@ClassName='RichEdit20WPT') and (@Name='From')]"
    INSPECTOR_EMAIL_DATA_TO_FIELD = "//*[(@ClassName='RichEdit20WPT') and (@Name='To')]"
    INSPECTOR_EMAIL_DATA_SUBJECT = "//*[(@ClassName='RichEdit20WPT') and (@Name='Subject')]"
    INSPECTOR_EMAIL_DATA_SENT_DATE = "//*[(@ClassName='RichEdit20WPT') and (@Name='Sent')]"
    INSPECTOR_EMAIL_DATA_COMPOSING_CANVAS = "//*[(@AutomationId='Body') and (@Name='Page 1 content')]"

    # -- Available Page Methods -- #

    def inspector_get_subject_of_filed_email(self):
        """ Entering into Inspector View Window and Inspect elements. """
        print("The filed email is opened into Inspector view")

        """ Checks if filed email window is opened. """
        inspector_window_title = self.get_xpath(self.INSPECTOR_WINDOW_TITLE)
        print(inspector_window_title.get_attribute('HelpText') + ' is displayed')

        print(inspector_window_title.get_attribute('HelpText'))
        return inspector_window_title.get_attribute('HelpText')

    def inspector_get_title_of_new_email(self):
        """ Entering into Inspector View Window and Inspect elements. """
        try:
            print("The new email is opened into Inspector view")
            inspector_window_title = self.get_xpath(self.INSPECTOR_WINDOW_TITLE)
            print(inspector_window_title.get_attribute('HelpText') + ' is displayed')
            # assert inspector_window_title.get_attribute('HelpText') == "Untitled"
            return True
        except NoSuchElementException:
            return False

    def inspector_get_email_data(self):
        """ Entering into Inspector View Window and Inspect elements. """
        print("The filed email is opened into Inspector view")

        """ Checks if filed email window is opened. """
        inspector_window_title = self.get_xpath(self.INSPECTOR_WINDOW_TITLE)
        print(inspector_window_title.get_attribute('HelpText') + ' is displayed')

        items = self.get_classnames(self.INSPECTOR_EMAIL_DATA_CLASS)
        print("Found " + str(len(items)) + " items")

        email_data_items_list = []

        email_data_items = self.get_classnames(self.INSPECTOR_EMAIL_DATA_CLASS)

        for email_data_item in self.get_classnames_from_element(email_data_items[0],
                                                                self.INSPECTOR_EMAIL_DATA_OBJECTS_CLASS):
            print(email_data_item.get_attribute("Name"))

            email_data_items_list.append(email_data_item.get_attribute("Name"))

        filed_email_window_close_button = self.get_xpath(self.INSPECTOR_WINDOW_CLOSE_BUTTON)
        filed_email_window_close_button.click()

        # print email_data_items_list
        return email_data_items_list

    def inspector_compose_new_email_with_minimum_set_of_data(self):
        """ Compose new email from Inspector View Window. """
        print("Composing new email from Composer...")
        print("Check if To and Subject fields and also Canvas are empty")
        inspector_window_to_field = self.get_xpath(self.INSPECTOR_EMAIL_DATA_TO_FIELD)
        # assert inspector_window_to_field.get_attribute("Length") == 0
        inspector_window_to_field.send_keys("gugushzeroapp@gmail.com")
        inspector_window_subject_field = self.get_xpath(self.INSPECTOR_EMAIL_DATA_SUBJECT)
        # assert inspector_window_subject_field.get_attribute("Length") == 0
        inspector_window_subject_field.send_keys("Hi Gugush!")
        inspector_window_canvas = self.get_xpath(self.INSPECTOR_EMAIL_DATA_COMPOSING_CANVAS)
        # assert inspector_window_canvas.get_attribute("Length") == 0
        inspector_window_canvas.send_keys("Hi Gugush! How are you?")
        return True

    def inspector_reply_to_email_from_thread(self):
        """ Replying to an email in thread from Inspector View Window. """
        print("Replying to email in thread from Composer...")
        inspector_window_canvas = self.get_xpath(self.INSPECTOR_EMAIL_DATA_COMPOSING_CANVAS)
        inspector_window_canvas.send_keys("Hi Harut! This is the replied email.")
        return True

    def inspector_forward_the_email_from_thread_to_the_same_sender(self):
        """ Replying the email in thread from Inspector View Window. """
        print("Forwarding the email in thread from Composer...")
        inspector_window_to_field = self.get_xpath(self.INSPECTOR_EMAIL_DATA_TO_FIELD)
        inspector_window_to_field.send_keys("harutzeroapp2@gmail.com")
        inspector_window_canvas = self.get_xpath(self.INSPECTOR_EMAIL_DATA_COMPOSING_CANVAS)
        inspector_window_canvas.send_keys("Hi Harut! This is the forwarded email.")
        return True

    def inspector_forward_the_email_from_thread(self):
        """ Replying the email in thread from Inspector View Window. """
        print("Forwarding the email in thread from Composer...")
        inspector_window_to_field = self.get_xpath(self.INSPECTOR_EMAIL_DATA_TO_FIELD)
        inspector_window_to_field.send_keys("gugushzeroapp@gmail.com")
        inspector_window_canvas = self.get_xpath(self.INSPECTOR_EMAIL_DATA_COMPOSING_CANVAS)
        inspector_window_canvas.send_keys("Hi Gugush! How are you?")
        return True

    def inspector_send_new_email(self):
        """ Sending new email from Inspector View Window. """
        print("Sending new email from Composer...")
        inspector_window_send_button = self.get_xpath(self.INSPECTOR_WINDOW_SEND_BUTTON)
        inspector_window_send_button.click()
        return True
