import time

import pyautogui
from selenium.common.exceptions import NoSuchElementException

from Base.BasePage import BasePage
from Resources.config import side_pane_attributes
from Utils.CabinetProfiles import rmkb_replicated
from Utils.DestinationParser import dest_parser


class TaskPanePage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    def __init__(self):
        super(TaskPanePage, self).__init__()
        self.re_file_button = None

    @staticmethod
    def inst():
        if TaskPanePage.__instance is None:
            TaskPanePage.__instance = TaskPanePage()
        return TaskPanePage.__instance

    # -- Elements -- #

    TASK_PANE_VIEW = "TaskPaneView"
    TASK_PANE = "TaskPane"
    TASK_PANE_TEXT = "Zero: Email filing"
    QUICK_FILE_BUTTON = ".//*[(@AutomationId='QuickFile') and (@IsOffscreen='False')]"
    FILE_BUTTON = ".//*[(@AutomationId='File') and (@IsOffscreen='False')]"
    UNFILE_BUTTON = ".//*[(@AutomationId='Unfile') and (@IsOffscreen='False')]"
    REFILE_BUTTON = ".//*[(@Name='Re-file >') and (@IsOffscreen='False')]"
    PREDICTION_TEXTS = ".//*[(@ClassName='TextBlock') and (@IsOffscreen='False')]"
    TASK_PANE_REFILE_BUTTON = "//*[(@AutomationId='ChooseDifferentAttributes') and (@Name='Re-file >')]"
    TASK_PANE_CHOOSE_DIFF_ATTR_BUTTON = "//*[(@AutomationId='ChooseDifferentAttributes') and (@Name='Choose Different Attributes >')]"
    TASK_PANE_SCROLL_BAR = ".//*[(@ClassName='Thumb') and (@IsOffscreen='False')]"
    AUTOFILE_CHECKBOX_CLASS = ".//*[(@ClassName='CheckBox') and (@IsOffscreen='False')]"
    AUTOFILE_CHECKBOX = "CheckBox"
    AUTOFILE_DIALOG = 'AutoFile option'
    AUTOFILE_DIALOG_CLASS = "AutoFileConfirmationView"
    AUTOFILE_DIALOG_OK = 'OK'
    AUTOFILE_DIALOG_CLOSE = 'Close'
    REFILE_DIALOG_BUTTON = "Refile"
    TASK_PANE_FIELDS_CLASS = "TextBlock"
    TASK_PANE_LISTBOX_ITEMS_CLASS = "GroupItem"
    TASK_PANE_LISTBOX_BUTTON_CLASS = "TextBlock"
    TASK_PANE_DESTINATION = "TextBlock"
    TASK_PANE_OPTIONS = "Task Pane Options"
    TASK_PANE_OPTIONS_CLOSE_BUTTON = "Close"
    TASK_PANE_ADD_TO_RECENT = "AddToRecentOnFile"

    SUBJECT = 'TextBox'
    CLIENT = ".//*[(@Name='ClientRmkb*') and (@IsOffscreen='False')]"
    MATTER = ".//*[(@Name='MatterRmkb*') and (@IsOffscreen='False')]"
    AUTHOR = ".//*[(@Name='AuthorRmkb*') and (@IsOffscreen='False')]"
    DOC_TYPE = ".//*[(@Name='Document TypeRmkb*') and (@IsOffscreen='False')]"
    DESCRIPTION = ".//*[(@Name='DescriptionRmkb') and (@IsOffscreen='False')]"
    LEGACY_DOC_ID = ".//*[(@Name='Legacy Doc IDRmkb') and (@IsOffscreen='False')]"
    ATTR_FIELD_XPATH = ".//*[(@AutomationId='AutosuggestBox') and (@IsOffscreen='False')]"
    ATTR_FIELD_ID = "AutosuggestBox"
    ATTR_VALUE_ID = "textBoxSearch"
    ATTR_DROPDOWN = ".//*[(@ClassName='Button') and (@IsOffscreen='False')]"
    ATTR_ITEM = ".//*[(@ClassName='TextBlock') and (@IsOffscreen='False')]"
    ATTR_VALUE_LIST_ITEM_CLASSNAME = "ListBoxItem"
    LIST_BOX_SEARCH_RESULTS = 'listBoxSearchResults'
    LIST_BOX_SEARCH_GROUPS = "GroupItem"
    GROUP_ITEM = ".//*[(@ClassName='GroupItem') and (@IsOffscreen='False')]"
    MATTER_NAME = "MatterRmkb*"

    # -- Available Page Methods -- #

    def get_custom_attribute_values(self):
        task_pane_element = self.wait_and_get_classname(self.TASK_PANE_VIEW)
        elements_list = self.get_xpaths_from_element(task_pane_element, ".//*[(@ClassName='TextBox') and (@IsOffscreen='False')]")
        attribute_values = {'subject': elements_list[0].text}
        elements_list.pop(0)
        for i in range(0, len(side_pane_attributes)):
            attribute_values[side_pane_attributes[i]] = elements_list[i].text
        return attribute_values


    def get_attributes_list(self):
        return [
            self.get_xpath_from_element(self.get_classname(self.TASK_PANE), self.CLIENT),
            self.get_xpath_from_element(self.get_classname(self.TASK_PANE), self.MATTER),
            self.get_xpath_from_element(self.get_classname(self.TASK_PANE), self.AUTHOR),
            self.get_xpath_from_element(self.get_classname(self.TASK_PANE), self.DOC_TYPE),
            self.get_xpath_from_element(self.get_classname(self.TASK_PANE), self.DESCRIPTION),
            self.get_xpath_from_element(self.get_classname(self.TASK_PANE), self.LEGACY_DOC_ID)
        ]

    def close_task_pane(self):
        """ Closes task pane by upper right corner X button. """
        task_pane_options = self.get_name(self.TASK_PANE_OPTIONS)
        task_pane_options.click()
        self.get_name_from_element(task_pane_options, self.TASK_PANE_OPTIONS_CLOSE_BUTTON).click()
        return True

    def is_opened(self):
        """ Checks if TaskPane is opened. Returns True or raises TimeoutException. """
        try:
            self.get_classname(self.TASK_PANE_VIEW)
            print("Task Pane opened")
            self.get_name("Zero: Email filing")
            print("Task Pane text is visible")
            return True
        except NoSuchElementException:
            return False

    def check_add_to_recent(self):
        self.get_id(self.TASK_PANE_ADD_TO_RECENT).click()

    def get_quick_file_buttons(self):
        """ Returns a list of quick file buttons. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        quick_file_buttons = self.get_xpaths_from_element(task_pane_element, self.QUICK_FILE_BUTTON)
        return quick_file_buttons

    def check_taskpane_state(self, status):
        """ Takes a status and returns True if status corresponds to Taskpane state, otherwise returns False. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        quick_file_buttons = self.get_xpaths_from_element(task_pane_element, self.QUICK_FILE_BUTTON)
        if status == "Ready to file":
            assert len(quick_file_buttons) >= 1
            return True
        elif status == "Filed":
            self.wait_and_get_xpath(self.REFILE_BUTTON)
            content_list_elements = self.get_filed_message_content()
            content_list = []
            for i in content_list_elements:
                content_list.append(i.get_attribute("HelpText"))
            dest_list = dest_parser(content_list[0])
            print(dest_list)
            print(content_list)
            assert content_list[1] in rmkb_replicated[0]
            assert content_list[3] in rmkb_replicated[1]
            assert content_list[5] in rmkb_replicated[2]
            assert content_list[7] in rmkb_replicated[3]
            assert content_list[2] in dest_list[0]
            assert content_list[4] in dest_list[1]
            assert content_list[6] in dest_list[2]
            assert content_list[8].split(" -")[0] in dest_list[3]
            self.get_xpath(self.REFILE_BUTTON)
            self.get_classname(self.AUTOFILE_CHECKBOX)
            return True
        elif status == "Unfiled" or status == "No Filing":
            assert len(self.get_xpaths_from_element(task_pane_element, self.REFILE_BUTTON)) == 0
            return True

    def re_file_message(self):
        """  Clicks refile button.  """
        task_pane_element = self.get_classname(self.TASK_PANE)
        # print task_pane_element + ' task pane element is found'
        re_file_button = self.get_xpath_from_element(task_pane_element, self.TASK_PANE_REFILE_BUTTON)
        # print re_file_button + ' a button into task pane is found'
        # assert re_file_button.get_attribute("Name") == "Refile"
        re_file_button.click()
        return True

    def click_on_choose_diff_attrs_button(self):
        """  Clicks refile button.  """
        task_pane_element = self.get_classname(self.TASK_PANE)
        choose_diff_attrs_button = self.get_xpath_from_element(task_pane_element,
                                                               self.TASK_PANE_CHOOSE_DIFF_ATTR_BUTTON)
        # assert re_file_button.get_attribute("Name") == "Refile"
        choose_diff_attrs_button.click()
        return True

    def quickfile_higher_weight(self, autofile=False):
        """ Quick files with higher weight. By default autofile turned off. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        quick_file_buttons = self.get_xpaths_from_element(task_pane_element, self.QUICK_FILE_BUTTON)
        if quick_file_buttons:
            if autofile:
                self.get_classname_from_element(quick_file_buttons[0].parent, self.AUTOFILE_CHECKBOX).click()
                self.get_name(self.AUTOFILE_DIALOG_OK).click()
            quick_file_buttons[0].click()
            return True
        else:
            print("No QuickFile buttons found")
            return False

    def fill_given_attribute(self, attr_field, value):
        """ Takes an attribute, fills it with given value. """
        attr_field.send_keys(value)
        time.sleep(2)
        search_results = self.get_xpath(self.LIST_BOX_SEARCH_RESULTS)
        self.get_xpaths_from_element(search_results, self.ATTR_ITEM)[0].click()
        # attr_field.send_keys(Keys.ENTER)

    def get_attribute_value(self, attribute_name):
        """ Takes attribute name and returns its value. """
        attribute_field = None
        task_pane_element = self.get_classname(self.TASK_PANE)
        attr_field_list = self.get_ids_from_element(task_pane_element, self.ATTR_FIELD_ID)
        if attribute_name == 'Client':
            attribute_field = attr_field_list[0]
        elif attribute_name == 'Matter':
            attribute_field = attr_field_list[1]
        elif attribute_name == 'Author':
            attribute_field = attr_field_list[2]
        elif attribute_name == 'Doctype':
            attribute_field = attr_field_list[3]
        else:
            return attribute_field
        return self.get_id_from_element(attribute_field, self.ATTR_VALUE_ID).text

    def get_attribute_field(self, attribute_name):
        """ Takes attribute name and returns its value. """
        attribute_field = None
        attr_field_list = self.get_ids(self.ATTR_FIELD_ID)
        if attribute_name == 'Client':
            attribute_field = attr_field_list[0]
        elif attribute_name == 'Matter':
            attribute_field = attr_field_list[1]
        elif attribute_name == 'Author':
            attribute_field = attr_field_list[2]
        elif attribute_name == 'Doctype':
            attribute_field = attr_field_list[3]
        else:
            return attribute_field
        return attribute_field

    def get_attribute_all_results(self, attr_field):
        self.get_xpath_from_element(attr_field, self.ATTR_DROPDOWN).click()
        print("Search clicked")
        self.wait(5)
        search_groups = self.get_classnames_from_element(self.get_id(self.LIST_BOX_SEARCH_RESULTS),
                                                         self.LIST_BOX_SEARCH_GROUPS)
        if len(search_groups) > 1:
            return self.get_classnames_from_element(search_groups[1], self.ATTR_VALUE_LIST_ITEM_CLASSNAME)
        return self.get_classnames_from_element(search_groups[0], self.ATTR_VALUE_LIST_ITEM_CLASSNAME)

    def get_attribute_recent_results(self, attr_field):
        self.get_xpath_from_element(attr_field, self.ATTR_DROPDOWN).click()
        print("Search clicked")
        self.wait(5)
        search_groups = self.get_classnames_from_element(self.get_id(self.LIST_BOX_SEARCH_RESULTS),
                                                         self.LIST_BOX_SEARCH_GROUPS)
        if len(search_groups) > 1:
            return self.get_classnames_from_element(search_groups[0], self.ATTR_VALUE_LIST_ITEM_CLASSNAME)
        else:
            print("No Recent Results")
            return None

    def set_attribute_value(self, attribute_name, value=None):
        """ Takes attribute name, sets value and returns value if filled randomly. """
        attribute_field = None
        task_pane_element = self.get_classname(self.TASK_PANE)
        attr_field_list = self.get_ids_from_element(task_pane_element, self.ATTR_FIELD_ID)
        if attribute_name == 'Client':
            attribute_field = attr_field_list[0]
        elif attribute_name == 'Matter':
            attribute_field = attr_field_list[1]
        elif attribute_name == 'Author':
            attribute_field = attr_field_list[2]
        elif attribute_name == 'Doctype':
            attribute_field = attr_field_list[4]
        else:
            return attribute_field
        if not value:
            return self.set_random_attribute_value(attribute_field)
        return self.set_custom_attribute_value(attribute_field, value)

    def click_file_button(self):
        self.get_xpath(self.FILE_BUTTON).click()
        return True

    def click_unfile_button(self):
        self.get_xpath(self.UNFILE_BUTTON).click()
        return True

    def set_random_attribute_value(self, attr_field):
        """ Takes an attribute field, randomly fills it and returns value. """
        self.get_xpath_from_element(attr_field, self.ATTR_DROPDOWN).click()
        print("Search clicked")
        search_results = self.get_id(self.LIST_BOX_SEARCH_RESULTS)
        print("Search opened")
        first_item = self.get_xpath_from_element(search_results, self.ATTR_ITEM)
        print("Item found")
        print(first_item)
        first_item.click()
        return self.get_id_from_element(attr_field, self.ATTR_VALUE_ID).text

    def set_custom_attribute_value(self, attr_field, value):
        attr_field.send_keys(value)
        search_results = self.get_id(self.LIST_BOX_SEARCH_RESULTS)
        print("Search opened")
        first_item = self.get_xpath_from_element(search_results, self.ATTR_ITEM)
        first_item.click()
        return True

    def random_file_no_predictions(self):
        """ Fills attributes with random values. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        attr_fileds = self.get_xpaths_from_element(task_pane_element, self.ATTR_FIELD_XPATH)
        for i in attr_fileds:
            self.set_random_attribute_value(i)
        self.get_xpath(self.FILE_BUTTON).click()

    def get_subject(self):
        """ Returns the Subject text. """
        subject = self.get_classname(self.SUBJECT)
        return subject

    def get_auto_file_checkboxes(self):
        """ Returns a list of quick file buttons. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        quick_file_buttons = self.get_xpaths_from_element(task_pane_element, self.AUTOFILE_CHECKBOX_CLASS)
        return quick_file_buttons

    def click_on_auto_file_checkbox_with_diff_attrs(self):
        """ Returns a list of autofile checkboxes. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        auto_file_checkboxes = self.get_xpaths_from_element(task_pane_element, self.AUTOFILE_CHECKBOX_CLASS)
        print("AutoFile this conversation checkbox is clicked")
        auto_file_checkboxes[-2].click()
        return True

    def get_auto_file_checkbox_state(self):
        """ Returns the state of AutoFile checkbox. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        # return self.get_classname_from_element(task_pane_element, self.AUTOFILE_CHECKBOX).get_attribute("ToggleState")
        return self.get_classname_from_element(task_pane_element, self.AUTOFILE_CHECKBOX).is_selected()

    def click_on_auto_file_checkbox(self):
        """ Clicks on AutoFile checkbox. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        # return self.get_classname_from_element(task_pane_element, self.AUTOFILE_CHECKBOX).get_attribute("ToggleState")
        self.get_classname_from_element(task_pane_element, self.AUTOFILE_CHECKBOX).click()
        return True

    def auto_file_checkbox_dialog_handling(self):
        """ Handling of AutoFile checkbox dialog window. """
        self.get_classname(self.AUTOFILE_DIALOG_CLASS)
        print("AutoFile option dialog window is opened")
        autofile_option_dialog = self.get_name(self.AUTOFILE_DIALOG)
        print("AutoFile option dialog window text is visible")
        self.get_name_from_element(autofile_option_dialog, self.AUTOFILE_DIALOG_OK).click()
        return True

    def re_file_dialog(self):
        """ Entering into Re-Filing Dialog Window and Inspect elements. """
        refiling_button = self.get_name(self.REFILE_DIALOG_BUTTON)
        assert refiling_button.get_attribute("Name") == "Refile"
        print("RE-FILING DIALOG IS INSPECTED")
        refiling_button.click()
        return True

    def get_filed_message_destination(self):
        """ Returns filed message destination. """
        task_pane_element = self.get_classname(self.TASK_PANE)
        return self.get_classname_from_element(task_pane_element, self.TASK_PANE_DESTINATION).get_attribute("Name")

    def scroll_to_locate_file_button(self):
        task_pane_element = self.get_classname(self.TASK_PANE)
        scroll_bar = self.get_xpath(self.TASK_PANE_SCROLL_BAR)
        # scroll_bar.scroll(-3)
        # pyautogui.scroll(-3, x=None, y=None)
        pyautogui.scroll(-20)
        return True

    def get_filed_message_content(self):
        task_pane_element = self.get_classname(self.TASK_PANE)
        return self.get_xpaths_from_element(task_pane_element, self.PREDICTION_TEXTS)

    def get_autofile_state(self):
        return self.get_classname(self.AUTOFILE_CHECKBOX).is_selected()
