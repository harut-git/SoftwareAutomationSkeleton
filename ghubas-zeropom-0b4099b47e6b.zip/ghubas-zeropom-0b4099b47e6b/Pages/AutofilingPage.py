from Base.BasePage import BasePage


class AutofilingPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if AutofilingPage.__instance is None:
            AutofilingPage.__instance = AutofilingPage()
        return AutofilingPage.__instance

        # -- Elements -- #

        # -- Available Page Methods -- #
