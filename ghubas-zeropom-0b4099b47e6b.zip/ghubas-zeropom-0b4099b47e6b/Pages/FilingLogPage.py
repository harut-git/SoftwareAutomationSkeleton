from pyautogui import press
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.action_chains import ActionChains

from Base.BasePage import BasePage
from Pages.Models import MessageElement


class FilingLogPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if FilingLogPage.__instance is None:
            FilingLogPage.__instance = FilingLogPage()
        return FilingLogPage.__instance

    # -- Elements -- #

    EMPTY_MESSAGE = 'Filing Log is empty'
    FILINGLOG_LIST_CLASSNAME = "DataGrid"
    FILING_LOG_LIST_ELEMENT_CLASS_NAME = "DataGridRow"
    # FILINGLOG_LIST_GRID = "//*[(@ClassName='DataGrid') and (@ControlType='ControlType.DataGrid')]"
    FILINGLOG_LIST_CELL_CLASSNAME = "DataGridCell"
    FILINGLOG_LIST_CELL_ELEMENT_CLASSNAME = "TextBlock"
    # FILINGLOG_LIST_CELL_EMAIL_COLUMN = "//*[(@ClassName='DataGridCell') and (@Column='0')]"
    FILINGLOG_LIST_CELL_AUTOFILE_CHECKBOX = "CheckBox"
    FILINGLOG_WINDOW_ID = "TitleBar"
    FILINGLOG_HEADER = "DataGridColumnHeadersPresenter"
    UNFILE_EMAIL_BUTTON = "Unfile"
    FILING_LOG_TEXTBOX = "//*[(@AutomationId='notSelectedTbx')]"
    # FILING_LOG_CLOSE_BUTTON = "//*[(@AutomationId='Close')]"
    # FILING_LOG_CLOSE_BUTTON = "//*[(@AutomationId='Close') and (@IsOffscreen='False')]"
    FILING_LOG_CLOSE_BUTTON = 'Close'
    FILING_LOG_DESTINATION = "TextBlock"

    FILINGLOG_OPENED_EMAIL_TITLE = "//*[(@ClassName='NetUIOfficeCaption') and (@ControlType='ControlType.TitleBar')]"
    FILINGLOG_OPENED_EMAIL_CLOSE_BUTTON = "//*[(@ClassName='NetUIAppFrameHelper') and (@Name='Close')]"

    UNFILE_EMAIL_WINDOW_TITLE = "//*[(@AutomationId='TitleBar')]"
    # FILINGLOG_UNFILE_EMAIL_BUTTON = "//*[(@AutomationId='File')]"
    FILINGLOG_UNFILE_EMAIL_BUTTON = 'Unfile'
    ZERO_FILINGLOG_BUTTON = 'Filing Log'

    # -- Available Page Methods -- #

    def filinglog_is_opened(self):
        """ Returns True if Filing Log dialog is opened or raises TimeoutException. """
        self.get_id(self.FILINGLOG_WINDOW_ID)
        self.get_classname(self.FILINGLOG_HEADER)
        return True

    def get_first_filed_message(self):
        filed_message_list = self.get_classnames_from_element(self.get_classname(self.FILINGLOG_LIST_CLASSNAME),
                                                              self.FILING_LOG_LIST_ELEMENT_CLASS_NAME)
        return filed_message_list[0]

    def get_filed_message_params(self, filed_message_element):
        element_list = self.get_classnames_from_element(filed_message_element,
                                                        self.FILINGLOG_LIST_CELL_ELEMENT_CLASSNAME)
        autofile_element = self.get_classname_from_element(filed_message_element,
                                                           self.FILINGLOG_LIST_CELL_AUTOFILE_CHECKBOX)
        filed_msg_obj = MessageElement(
            msg_from=element_list[0].get_attribute("Name"),
            msg_subject=element_list[1].get_attribute("Name"),
            msg_sent_date=element_list[2].get_attribute("Name"),
            msg_destination=element_list[3].get_attribute("Name"),
            msg_filed_date=element_list[4].get_attribute("Name"),
            msg_auto_filed=autofile_element.is_selected(),
            msg_status='Filed'
        )
        return filed_msg_obj

    def close_filinglog_dialog(self):
        """ Close Filing Log Dialog Window. """
        filinglog_pane = self.get_name("Filing Logs")
        filinglog_close_button = filinglog_pane.find_element_by_name(self.FILING_LOG_CLOSE_BUTTON)
        filinglog_close_button.click()
        return True

    def get_destination_of_filed_email(self):
        """ Entering into Filing Log Dialog Window and Inspect elements. """
        messages = self.get_classnames(self.FILINGLOG_LIST_CELL_CLASSNAME)
        print("Found " + str(len(messages)) + " messages")
        messages[-3].click()
        return self.get_classname_from_element(messages[-3], self.FILING_LOG_DESTINATION).get_attribute("Name")

    def filinglog_dialog_from_datagrid_get_email_subject(self):
        """ Entering into Filing Log Dialog Window and Inspect elements. """
        first_cell = self.get_classname(self.FILINGLOG_LIST_CELL_CLASSNAME)
        cell_texts = self.get_classnames_from_element(first_cell, self.FILINGLOG_LIST_CELL_ELEMENT_CLASSNAME)
        return cell_texts[1].get_attribute("Name")

    def filinglog_dialog_from_datagrid_get_email_subject_sender_sent_and_filed_dates(self):
        """ Entering into Filing Log Dialog Window and Inspect elements. """
        messages = self.get_classnames(self.FILINGLOG_LIST_CELL_CLASSNAME)
        print("Found " + str(len(messages)) + " messages")

        filed_email_data_list = []

        filinglog_list_cell_elements = self.get_classnames(self.FILINGLOG_LIST_CELL_CLASSNAME)

        for i in range(len(messages) - 4, len(messages) - 1):

            for cell_text_block_list in self.get_classnames_from_element(filinglog_list_cell_elements[i],
                                                                         self.FILINGLOG_LIST_CELL_ELEMENT_CLASSNAME):
                # print(cell_text_block_list.get_attribute("Name")

                filed_email_data_list.append(cell_text_block_list.get_attribute("Name"))

        # print(filed_email_attr_list
        return filed_email_data_list

    def filing_log_is_empty(self):
        """ Entering into Filing Log Dialog Window and Inspect elements if it is empty. """
        # pane = self.get_name("Filing logs")
        filinglog_textbox_text = self.get_xpath(self.FILING_LOG_TEXTBOX)
        assert filinglog_textbox_text.get_attribute("Name") == "Nothing is selected"
        print("FILING LOG DIALOG IS INSPECTED")
        filinglog_close_button = self.get_xpath(self.FILING_LOG_CLOSE_BUTTON)
        filinglog_close_button.click()
        return True

    def scroll_to_find_message_by_subject(self, subject):
        first_message_email = self.get_classname(self.FILINGLOG_LIST_CELL_CLASSNAME)
        first_message_email.click()
        scroll_needed = True
        while scroll_needed:
            try:
                self.get_name_from_element(self.get_classname(self.FILINGLOG_LIST_CLASSNAME), subject)
                scroll_needed = False
            except Exception:
                for _ in range(7):
                    press('pgdn')
                print("still not found")

    def filinglog_dialog_datagrid_get_attributes(self):
        """ Entering into Filing Log Dialog Window and Inspect elements. """
        messages = self.get_classnames(self.FILINGLOG_LIST_CELL_CLASSNAME)
        # messages = self.get_xpaths(self.FILINGLOG_LIST_CELL_EMAIL_COLUMN)
        print("Found " + str(len(messages)) + " messages")

        for i in range(len(messages)):
            if i % 4 == 0:
                # print("The current index is " + str(i) + "."
                self.wait(1)
                # messages[0].double_click()
                messages[i].click()
                self.wait(1)

                # filinglog_list_cell_elements = self.get_xpaths(self.FILINGLOG_LIST_CELL_EMAIL_COLUMN)
                filinglog_list_cell_elements = self.get_classnames(self.FILINGLOG_LIST_CELL_CLASSNAME)

                for j in self.get_classnames_from_element(filinglog_list_cell_elements[i],
                                                          self.FILINGLOG_LIST_CELL_ELEMENT_CLASSNAME):
                    print(j.get_attribute("Name"))

    def get_autofile_checkbox_status_from_last_message(self):
        """ Entering into Filing Log Dialog Window and count the AutoFile checkboxes elements. """
        autofile_checkboxes = self.get_classnames(self.FILINGLOG_LIST_CELL_AUTOFILE_CHECKBOX)
        print("Found " + str(len(autofile_checkboxes)) + " autofile checkboxes")

        return self.get_classname_from_element(autofile_checkboxes[-1],
                                               self.FILINGLOG_LIST_CELL_AUTOFILE_CHECKBOX).is_selected()

    def filinglog_dialog_open_filed_email_by_double_click(self):
        """ Entering into Filing Log Dialog Window and Inspect elements. """
        first_cell = self.get_classname(self.FILINGLOG_LIST_CELL_CLASSNAME)
        first_cell.click()
        actions = ActionChains(self.driver)
        actions.double_click(first_cell).perform()

        self.wait(2)

        print("Double click action is performed ")

    def filinglog_dialog_unfile_filed_email(self):
        """ Entering into Filing Log Dialog Window and Count the filed emails in the list. """
        messages_before = self.get_classnames(self.FILINGLOG_LIST_CELL_CLASSNAME)
        print("Found " + str(len(messages_before)) + " messages BEFORE.")

        last_index = len(messages_before) - 1
        print("The last email index able to unfile " + str(last_index))
        messages_before[last_index].click()

        """ Checks if Unfile emails window is opened. """
        # self.wait_and_get_name(self.unfile_window, wait_seconds=2)
        # unfile_email_text = self.get_xpath(self.UNFILE_EMAIL_WINDOW_TITLE)
        # assert unfile_email_text.get_attribute("Name") == "UnFile emails"
        # print("Unfile emails window is opened"

        # unfile_email_button = self.get_xpath(self.FILINGLOG_UNFILE_EMAIL_BUTTON)
        # unfile_email_button.click()

        """ Entering into Unfile Emails Dialog Window. """
        unfile_pane = self.get_name("UnFile emails")
        unfile_email_button = unfile_pane.find_element_by_name(self.FILINGLOG_UNFILE_EMAIL_BUTTON)
        """ Clicks Close button in Restart Dialog. """
        unfile_email_button.click()
        print("CLOSE IS CLICKED")

        """ Close Filing Log Dialog Window. """
        filinglog_pane = self.get_name("Filing Logs")
        filinglog_close_button = filinglog_pane.find_element_by_name(self.FILING_LOG_CLOSE_BUTTON)
        filinglog_close_button.click()

        """ Clicks Filing Log button in Outlook Add-in section. """
        filinglog_button = self.wait_and_get_name(self.ZERO_FILINGLOG_BUTTON, 60)
        print(filinglog_button.get_attribute('Name') + ' is displayed')
        self.wait(1)
        filinglog_button.click()
        self.wait(1)
        print("FILING LOG IS CLICKED")

        """ Entering into Filing Log Dialog Window and Count the filed emails in the list. """
        messages_after = self.get_classnames(self.FILINGLOG_LIST_CELL_CLASSNAME)
        print("Found " + str(len(messages_after)) + " messages AFTER.")

        assert messages_before - messages_after == 4 is True

    def unfile_message(self):
        unfile_btn = self.get_id(self.UNFILE_EMAIL_BUTTON)
        unfile_btn.click()

    def is_empty(self):
        try:
            self.wait_and_get_name(self.EMPTY_MESSAGE, 15)
            return True
        except TimeoutException:
            print("No Filing Log Message were shown")
            return False
