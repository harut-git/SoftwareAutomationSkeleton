from selenium.webdriver.support.wait import WebDriverWait

from Base.BasePage import BasePage


class AddinsPage(BasePage):
    """ Singleton design pattern implementation """
    __instance = None

    @staticmethod
    def inst():
        if AddinsPage.__instance is None:
            AddinsPage.__instance = AddinsPage()
        return AddinsPage.__instance

    # -- Elements -- #

    ZERO_TEXT = 'Zero'
    ZERO_BUTTON = 'Login'
    USERNAME = 'Username'
    PASSWORD = 'Password'
    LOGIN = 'Login'
    ALLOW = 'Allow'
    ALERT_YES = 'Yes'
    USERNAME_IMANAGE_SAML = 'User name'
    IMANAGE_LOGIN_OK = 'OK'

    MORE_CHOICES_BUTTON = 'More choices'
    DIFF_ACCOUNT_BUTTON = 'Use a different account'

    # -- Available Page Methods -- #

    def check_addin_visible(self):
        """ Checks if Zero text and button are available in Outlook Add-ins section. """
        addin_button = self.wait_and_get_name(self.ZERO_BUTTON)
        addin_text = self.wait_and_get_name(self.ZERO_TEXT)
        print(addin_text.get_attribute('Name') + ' is displayed')
        return True

    def addin_login(self):
        """ Clicks Login button in Outlook Add-in section. """
        login_button = self.wait_and_get_name(self.ZERO_BUTTON)
        login_button.click()
        print("ZERO LOGIN IS CLICKED")

    def nd_frame_login(self):
        """ Logins to Zero Addin by ND credentials in ND Frame """
        pane = self.wait_and_get_name("NetDocuments")
        username_field = pane.find_element_by_name(self.USERNAME)
        password_field = pane.find_element_by_name(self.PASSWORD)
        login_button = pane.find_element_by_name(self.LOGIN)
        username_field.send_keys("outlook-qa-automate@zeroapp.ai")
        password_field.send_keys("InboxZero123")
        login_button.click()
        allow = self.wait_and_get_name(self.ALLOW, 30)
        allow.click()
        print("ND LOGIN IS CLICKED")

    def show_pane(self):
        """ Clicks 'Show Zero Pane' button in Outlook Add-in section. """
        login_button = self.wait_and_get_name(self.ZERO_BUTTON)
        login_button.click()
        print("Opening Pane by Clicking Show Zero Pane")

    def imanage_frame_login_saml(self):
        """ Logins to Zero Addin by iManage credentials in iManage Frame """

        """ Handling of Security Alert dialog 1 """
        try:
            alert_yes_button = self.wait_and_get_name(self.ALERT_YES)
            alert_yes_button.click()
        except RuntimeError:
            pass
        else:
            print("Moving forward with Security Alert dialog 1...")

        """ Handling of Security Alert dialog 1 """
        try:
            alert_yes_button = self.wait_and_get_name(self.ALERT_YES)
            alert_yes_button.click()
        except RuntimeError:
            pass
        else:
            print("Moving forward with Security Alert dialog 2...")

        pane = self.wait_and_get_name("Windows Security")
        more_button = pane.find_element_by_name(self.MORE_CHOICES_BUTTON)
        more_button.click()
        diff_account_button = pane.find_element_by_name(self.DIFF_ACCOUNT_BUTTON)
        diff_account_button.click()

        username_field = pane.find_element_by_name(self.USERNAME_IMANAGE_SAML)
        password_field = pane.find_element_by_name(self.PASSWORD)
        login_ok_button = pane.find_element_by_name(self.IMANAGE_LOGIN_OK)
        username_field.send_keys("imanager")
        password_field.send_keys("P@ssw0rdger")
        login_ok_button.click()
        print("iManage LOGIN IS CLICKED")
