import time
import unittest

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class BasePage(unittest.TestCase):
    """ This is base class. All page classes extend from it. """

    def __init__(self):
        """Constructor"""
        self.driver = webdriver.Remote(
            command_executor='http://localhost:9999',
            desired_capabilities={
                "debugConnectToRunningApp": 'true',
            })

    def get_name(self, name):
        """ Return the DOM element of the name or throw NoSuchElementException if the element is not found """
        return self.driver.find_element_by_name(name)

    def get_id(self, automation_id):
        """ Return the DOM element of the name or throw NoSuchElementException if the element is not found """
        return self.driver.find_element_by_id(automation_id)

    def get_classname(self, classname):
        """ Return the DOM element of the classname or throw NoSuchElementException if the element is not found """
        return self.driver.find_element_by_class_name(classname)

    def get_xpath(self, xpath):
        """ Return the DOM element of the xpath OR throws NoSuchElementException if the element is not found """
        return self.driver.find_element_by_xpath(xpath)

    def get_xpaths(self, xpath):
        """ Return a list of elements found by xpath or an empty list if no element found """
        return self.driver.find_elements_by_xpath(xpath)

    def get_ids(self, automation_id):
        """ Return a list of elements found by class or an empty list if no element found """
        return self.driver.find_elements_by_id(automation_id)

    def get_classnames(self, class_name):
        """ Return a list of elements found by class or an empty list if no element found """
        return self.driver.find_elements_by_class_name(class_name)

    def click_element(self, xpath):
        """ Click the element supplied """

    def wait(self, wait_seconds=5):
        """ Performs wait for time provided """
        time.sleep(wait_seconds)

    def wait_and_get_name(self, name, wait_seconds=60):
        """ Performs wait for time provided until element is visible or throws TimeoutException if the element
        is not found """
        element = WebDriverWait(self.driver, wait_seconds).until(
            EC.presence_of_element_located((By.NAME, name))
        )
        return self.driver.find_element_by_name(name)

    def wait_and_get_classname(self, classname, wait_seconds=60):
        """ Performs wait for time provided until element is visible or throws TimeoutException if the element
        is not found """
        element = WebDriverWait(self.driver, wait_seconds).until(
            EC.presence_of_element_located((By.CLASS_NAME, classname))
        )
        return self.driver.find_element_by_class_name(classname)

    def wait_and_get_xpath(self, xpath, wait_seconds=60):
        """ Performs wait for time provided until element is visible or throws TimeoutException if the element
        is not found """
        element = WebDriverWait(self.driver, wait_seconds).until(
            EC.presence_of_element_located((By.XPATH, xpath))
        )
        return self.driver.find_element_by_xpath(xpath)

    def get_name_from_element(self, element, name):
        """ Return the DOM element of the name or throw NoSuchElementException if the element is not found """
        return element.find_element_by_name(name)

    def get_xpath_from_element(self, element, xpath):
        """ Return the DOM element of the xpath or throw NoSuchElementException if the element is not found """
        return element.find_element_by_xpath(xpath)

    def get_classname_from_element(self, element, classname):
        """ Return the DOM element of the classname or throw NoSuchElementException if the element is not found """
        return element.find_element_by_class_name(classname)

    def get_id_from_element(self, element, automation_id):
        """ Return the DOM element of the id or throw NoSuchElementException if the element is not found """
        return element.find_element_by_id(automation_id)

    def get_classnames_from_element(self, element, classname):
        """ Return a list of elements found by class or an empty list if no element found """
        return element.find_elements_by_class_name(classname)

    def get_ids_from_element(self, element, automation_id):
        """ Return a list of elements found by id or an empty list if no element found """
        return element.find_elements_by_id(automation_id)

    def get_xpaths_from_element(self, element, xpath):
        """ Return a list of elements found by xpath or an empty list if no element found """
        return element.find_elements_by_xpath(xpath)

    def right_click_element(self, element):
        action_chains = ActionChains(self.driver)
        action_chains.context_click(element).perform()
