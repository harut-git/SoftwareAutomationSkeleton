import subprocess
import time
import unittest
from Pages.OutlookWindowPage import OutlookWindowPage
from Utils.PrepareData import empty_inbox, move_emails
from Utils.RegistryEditor import del_path, clean_restrictions
from Resources import config
from Utils.ProcessRunner import Runner, isprocessrunning
import win32com.client


class BaseSuite(unittest.TestCase):
    runner = Runner(outlook_path=config.OUTLOOK_PATH, winium_path=config.WINIUM_PATH)
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.GetDefaultFolder(6)
    data = inbox.parent.Folders("DATA")

    def setUp(self):
        """ Written below runs first while running any test from this TestCase. """
        print(del_path('DisabledItems'))
        print(del_path("StartupItems"))
        if self.runner.start_outlook() and self.runner.start_winium():
            if not OutlookWindowPage.inst().outlook_is_opened():
                print("Outlook not started")
                self.tearDown()
            print("Outlook is opened")
        else:
            self.tearDown()

    def tearDown(self):
        """ Written below runs after the end of test execution """
        empty_inbox(self.inbox)
        self.runner.close_outlook()
        print("Closing Windows Desktop Driver on port 9999")
        self.runner.close_winium()
        print("Closing Outlook")
        print("Clearing Inbox")
        print(del_path('StartupItems'))


class BaseClassSuite(unittest.TestCase):
    runner = Runner(outlook_path=config.OUTLOOK_PATH, winium_path=config.WINIUM_PATH)
    if isprocessrunning('OUTLOOK.EXE'.encode('utf-8')):
        print("Outlook opened DETECTED!!!")
        runner.close_outlook()
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.GetDefaultFolder(6)
    data = inbox.parent.Folders("DATA")


    @classmethod
    def setUpClass(cls):
        clean_restrictions()
        # start the service
        args = ['sc', 'stop', 'ZeroOutlookWcfServicesHost']
        # stop the service
        subprocess.run(args)
        time.sleep(5)
        # start the service
        args[1] = 'start'
        subprocess.run(args)
        """ get_some_resource() is slow, to avoid calling it for each test use setUpClass()
            and store the result as class variable
        """
        empty_inbox(cls.inbox)
        move_emails(cls.data.Folders(1), cls.inbox, 2)
        move_emails(cls.data.Folders(3), cls.inbox, 5)
        """ Written below runs first while running any test from this TestCase. """
        print(del_path('DisabledItems'))
        print(del_path("StartupItems"))
        if not isprocessrunning("Winium.Desktop.Driver.exe".encode('utf-8')):
            cls.runner.start_winium()
        if cls.runner.start_outlook():
            if not OutlookWindowPage.inst().outlook_is_running():
                print("Outlook not started")
                cls.tearDownClass()
            print("Outlook is opened")
        else:
            cls.tearDownClass()

    @classmethod
    def tearDownClass(cls):
        """ Written below runs after the end of test execution """
        empty_inbox(cls.inbox)
        cls.runner.close_outlook()
        print("Closing Windows Desktop Driver on port 9999")
        cls.runner.close_winium()
        print("Closing Outlook")
        print("Clearing Inbox")
        print(del_path('StartupItems'))
